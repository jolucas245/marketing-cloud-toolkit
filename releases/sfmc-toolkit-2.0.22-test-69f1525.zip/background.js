// src/background/apps.js
var STACK_RE = /^s?\d+$/;
var mdY = (t) => {
	const d = new Date(t);
	return `${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}-${d.getFullYear()}`;
};
var SETUP_SESSION = {
	landingTimeoutMs: (url) => url.includes("/cloud/#app/Setup/") ? 15e3 : 6e3,
	retryGapMs: 1e4
};
var SFMC_APPS = [
	{
		id: "automationStudio",
		name: "Automation Studio",
		matches: (url) => url.hostname.startsWith("mc.") && url.pathname.startsWith("/AutomationStudioFuel3/"),
		bearer: true,
		probeUrl: (s) => `https://mc.${s}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi/automation/v1/automations?$page=1&$pageSize=1`,
		landings: (s) => [`https://mc.${s}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`, `https://mc.${s}.exacttarget.com/cloud/#app/Automation%20Studio/AutomationStudioFuel3/`]
	},
	{
		id: "contactsMeta",
		name: "Data Extensions",
		matches: (url) => url.hostname.startsWith("mc.") && url.pathname.startsWith("/contactsmeta/"),
		bearer: true,
		probeUrl: (s) => `https://mc.${s}.marketingcloudapps.com/contactsmeta/fuelapi/legacy/v1/beta/folder`,
		landings: (s) => [`https://mc.${s}.marketingcloudapps.com/contactsmeta/`, `https://mc.${s}.exacttarget.com/cloud/#app/Contact%20Builder`]
	},
	{
		id: "dataUi",
		onDemand: true,
		name: "Data Extension storage",
		matches: (url) => url.hostname.startsWith("mc-data-ui."),
		bearer: true,
		probeUrl: (s) => `https://mc-data-ui.${s}.marketingcloudapps.com/fuelapi/data/v1/customobjects/storageHistory?startDate=${mdY(Date.now() - 864e5)}&endDate=${mdY(Date.now())}`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Contact%20Builder`]
	},
	{
		id: "contentBuilder",
		name: "Content Builder",
		matches: (url) => url.hostname.startsWith("content-builder."),
		bearer: true,
		csrfCookie: "_csrf",
		probeUrl: (s) => `https://content-builder.${s}.marketingcloudapps.com/fuelapi/asset/v1/content/categories/?categoryType=cloudpages&$page=1&$pagesize=1`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Content%20Builder`]
	},
	{
		id: "cloudPages",
		name: "CloudPages",
		matches: (url) => url.hostname.startsWith("cloud-pages."),
		bearer: false,
		probeUrl: (s) => `https://cloud-pages.${s}.marketingcloudapps.com/fuelapi/internal/v2/cloudpages/sites?$page=1&$pagesize=1`,
		landings: (s) => [`https://cloud-pages.${s}.marketingcloudapps.com/update-token.json`, `https://mc.${s}.exacttarget.com/cloud/#app/CloudPages`]
	},
	{
		id: "journeyBuilder",
		name: "Journey Builder",
		matches: (url) => url.hostname.startsWith("jbinteractions."),
		bearer: false,
		probeUrl: (s) => `https://jbinteractions.${s}.marketingcloudapps.com/fuelapi/interaction/v1/eventDefinitions?$page=1&$pagesize=1`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/#app/Journey%20Builder`]
	},
	{
		id: "emailApp",
		onDemand: true,
		name: "Sender authentication (Setup)",
		matches: (url) => url.hostname.startsWith("email-app."),
		bearer: false,
		probeUrl: (s) => `https://email-app.${s}.marketingcloudapps.com/fuelapi/messaging/v1/domainverification?$page=1&$pagesize=1`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/tools/SSO.aspx?appId=6df293a1-4fdc-41cd-aa08-89efc793c33c&env=default&legacy=1&deepLink=/%23/admin/domainverification`, `https://mc.${s}.exacttarget.com/cloud/#app/Setup/FromAddressManagement`],
		...SETUP_SESSION,
		sessionHint: "Open Setup > Feature Settings > Email Studio > From Address Management in Marketing Cloud: if it does not load there either, your user cannot view sender authentication."
	},
	{
		id: "customDomains",
		onDemand: true,
		name: "Custom domains (Setup)",
		matches: (url) => url.hostname.startsWith("custom-domains-ui."),
		bearer: false,
		probeUrl: (s) => `https://custom-domains-ui.${s}.marketingcloudapps.com/fuelapi/internal/v1/ssl/customdomains/?$page=1&$pageSize=1`,
		landings: (s) => [`https://custom-domains-ui.${s}.marketingcloudapps.com/`, `https://mc.${s}.exacttarget.com/cloud/#app/Setup/CustomDomains`],
		...SETUP_SESSION,
		sessionHint: "Open Setup > Security > Domain SSL Certificates in Marketing Cloud: if it does not load there either, your user cannot view custom domains."
	},
	{
		id: "domainAllowlist",
		onDemand: true,
		name: "Account endpoints (Setup)",
		matches: (url) => url.hostname.startsWith("mc-domainwhitelist-admin-app."),
		bearer: false,
		probeUrl: (s) => `https://mc-domainwhitelist-admin-app.${s}.marketingcloudapps.com/fuelapi/platform/v1/endpoints`,
		landings: (s) => [`https://mc.${s}.exacttarget.com/cloud/tools/SSO.aspx?appId=FF14944B-7CDB-4FF1-82DB-40F022C2C2DC&restToken=1`, `https://mc.${s}.exacttarget.com/cloud/#app/Setup/DomainWhitelist`],
		...SETUP_SESSION,
		sessionHint: "Open Setup > Security > Domain Allowlist in Marketing Cloud: if it does not load there either, your user cannot view the account endpoints."
	}
];
function findApp(appId) {
	return SFMC_APPS.find((a) => a.id === appId) || null;
}
function resolveUrl(rawUrl) {
	let url;
	try {
		url = new URL(rawUrl);
	} catch {
		return {
			stack: null,
			family: null,
			app: null
		};
	}
	const labels = url.hostname.split(".");
	const stack = labels.length >= 4 && STACK_RE.test(labels[1]) ? labels[1] : null;
	if (/^(?:mc|members)\.[^.]+\.exacttarget\.com$/.test(url.hostname)) return {
		stack,
		family: "core",
		app: null
	};
	if (url.hostname.endsWith(".marketingcloudapps.com")) return {
		stack,
		family: "mca",
		app: SFMC_APPS.find((a) => a.matches(url)) || null
	};
	return {
		stack: null,
		family: null,
		app: null
	};
}
function stackFromPageUrl(rawUrl) {
	if (!rawUrl || rawUrl.includes("/login") || rawUrl.includes("mc.login.")) return null;
	const m = rawUrl.match(/^https:\/\/[a-z-]+\.([^.]+)\.(?:exacttarget|marketingcloudapps)\.com\//);
	return m && STACK_RE.test(m[1]) ? m[1] : null;
}
// src/background/chromeAsync.js
function storageGet(area, keys) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].get(keys, (r) => resolve(r || {}));
		} catch {
			resolve({});
		}
	});
}
function storageSet(area, items) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].set(items, () => resolve());
		} catch {
			resolve();
		}
	});
}
/** Like storageSet, but resolves with Chrome's error message (for example the quota one), or null. */
function storageSetChecked(area, items) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].set(items, () => resolve(chrome.runtime?.lastError?.message || null));
		} catch (e) {
			resolve(e?.message || "Could not save");
		}
	});
}
function storageRemove(area, keys) {
	return new Promise((resolve) => {
		try {
			chrome.storage[area].remove(keys, () => resolve());
		} catch {
			resolve();
		}
	});
}
function queryTabs(queryInfo = {}) {
	return new Promise((resolve) => {
		try {
			chrome.tabs.query(queryInfo, (tabs) => resolve(tabs || []));
		} catch {
			resolve([]);
		}
	});
}
function getCookie(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.get(details, (c) => resolve(c || null));
		} catch {
			resolve(null);
		}
	});
}
function getAllCookies(details) {
	return new Promise((resolve) => {
		try {
			chrome.cookies.getAll(details, (c) => resolve(c || []));
		} catch {
			resolve([]);
		}
	});
}
function createTab(props) {
	return new Promise((resolve) => {
		try {
			chrome.tabs.create(props, (tab) => resolve(chrome.runtime.lastError ? null : tab || null));
		} catch {
			resolve(null);
		}
	});
}
function removeTab(tabId) {
	try {
		chrome.tabs.remove(tabId, () => void chrome.runtime.lastError);
	} catch {}
}
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
// src/background/stack.js
var STACK_IDS = [
	"s1",
	"s4",
	"s6",
	"s7",
	"s8",
	"s10",
	"s11",
	"s12",
	"s13",
	"s50",
	"s51",
	"401",
	"402",
	"403"
];
var CORE_AUTH_COOKIE_NAMES = /* @__PURE__ */ new Set([
	"ETAuthCookie",
	"ASP.NET_SessionId",
	"platformAuthCookie"
]);
var STACK_FROM_CORE_HOST = /^(?:mc|members)\.([^.]+)\.exacttarget\.com$/;
var sfmcSession = {};
var forgetHooks = [];
function onForgetStack(fn) {
	forgetHooks.push(fn);
}
var STACKLESS_PAGE = /^https:\/\/(?:mc|members)\.exacttarget\.com\//;
var STACK_IN_REQUEST = /^https:\/\/[a-z0-9-]+\.([^.]+)\.(?:exacttarget|marketingcloudapps)\.com\//;
var tabStacks = {};
var tabStacksLoaded = null;
function loadTabStacks() {
	if (!tabStacksLoaded) tabStacksLoaded = storageGet("session", "tabStacks").then((r) => {
		Object.assign(tabStacks, {
			...r.tabStacks || {},
			...tabStacks
		});
	}).catch(() => {});
	return tabStacksLoaded;
}
function noteRequestStack(details) {
	if (!details || details.tabId == null || details.tabId < 0) return;
	const m = String(details.url || "").match(STACK_IN_REQUEST);
	if (!m || !STACK_RE.test(m[1]) || tabStacks[details.tabId] === m[1]) return;
	tabStacks[details.tabId] = m[1];
	storageSet("session", { tabStacks: { ...tabStacks } });
}
function isStacklessPage(url) {
	return STACKLESS_PAGE.test(url || "") && !url.includes("/login") && !url.includes("mc.login.");
}
function tabStack(tab) {
	const fromUrl = stackFromPageUrl(tab?.url);
	if (fromUrl || !isStacklessPage(tab?.url)) return fromUrl;
	if (tabStacks[tab.id]) return tabStacks[tab.id];
	const ctx = sfmcSession[new URL(tab.url).hostname];
	return ctx?.stackKey && STACK_RE.test(ctx.stackKey) ? ctx.stackKey : null;
}
async function rememberActiveStack(url, tabId) {
	await loadTabStacks();
	const stack = tabStack({
		url,
		id: tabId
	});
	if (stack) storageSet("session", { lastActiveStack: {
		stack,
		ts: Date.now()
	} });
}
async function scanCookieStacks() {
	const now = Date.now() / 1e3;
	const stacks = [];
	for (const c of await getAllCookies({ domain: "exacttarget.com" })) {
		if (!CORE_AUTH_COOKIE_NAMES.has(c.name)) continue;
		if (c.expirationDate && c.expirationDate <= now) continue;
		const m = c.domain.replace(/^\./, "").match(STACK_FROM_CORE_HOST);
		if (m && STACK_RE.test(m[1]) && !stacks.includes(m[1])) stacks.push(m[1]);
	}
	return stacks;
}
async function openStackTabs() {
	await loadTabStacks();
	const list = [];
	const stackless = [];
	for (const t of await queryTabs({})) {
		const stack = tabStack(t);
		if (stack) list.push({
			stack,
			lastAccessed: t.lastAccessed || 0
		});
		else if (isStacklessPage(t.url)) stackless.push(t);
	}
	if (stackless.length) {
		const live = await firstLiveStack();
		if (live) for (const t of stackless) {
			noteRequestStack({
				tabId: t.id,
				url: `https://mc.${live}.exacttarget.com/`
			});
			list.push({
				stack: live,
				lastAccessed: t.lastAccessed || 0
			});
		}
	}
	return list.sort((a, b) => b.lastAccessed - a.lastAccessed);
}
function firstLiveStack() {
	return Promise.any(STACK_IDS.map((id) => verifyStack(id).then((ok) => {
		if (ok) return id;
		throw new Error("no");
	}))).catch(() => null);
}
async function verifyStack(stack) {
	try {
		return (await fetch(`https://mc.${stack}.exacttarget.com/cloud/fuelapi/data-internal/v1/customobjects/category/0?retrievalType=1&$page=1&$pagesize=1`, {
			credentials: "include",
			redirect: "manual"
		})).status === 200;
	} catch {
		return false;
	}
}
function probeStacks() {
	return Promise.any(STACK_IDS.map((id) => fetch(`https://mc.${id}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`, {
		credentials: "include",
		redirect: "manual"
	}).then((r) => {
		if (r.status === 200) return id;
		throw new Error("not this stack");
	}))).catch(() => null);
}
async function collectStackCandidates() {
	const found = /* @__PURE__ */ new Map();
	const add = (stack, source) => {
		if (!stack || !STACK_RE.test(stack)) return;
		if (!found.has(stack)) found.set(stack, /* @__PURE__ */ new Set());
		found.get(stack).add(source);
	};
	for (const t of await openStackTabs()) add(t.stack, "tab");
	for (const s of await scanCookieStacks()) add(s, "cookie");
	for (const ctx of Object.values(sfmcSession)) add(ctx?.stackKey, "session");
	return [...found].map(([stack, sources]) => ({
		stack,
		sources: [...sources]
	}));
}
async function resolveStack() {
	const { stackOverride } = await storageGet("local", "stackOverride");
	if (stackOverride && STACK_RE.test(stackOverride)) return {
		stack: stackOverride,
		source: "manual"
	};
	const tabs = await openStackTabs();
	const { lastActiveStack } = await storageGet("session", "lastActiveStack");
	if (lastActiveStack?.stack && tabs.some((t) => t.stack === lastActiveStack.stack)) return {
		stack: lastActiveStack.stack,
		source: "tab"
	};
	if (tabs.length) return {
		stack: tabs[0].stack,
		source: "tab"
	};
	const cookieStacks = await scanCookieStacks();
	if (cookieStacks.length === 1) return {
		stack: cookieStacks[0],
		source: "cookie"
	};
	if (cookieStacks.length > 1) {
		const checks = await Promise.all(cookieStacks.map(verifyStack));
		const live = cookieStacks.find((_, i) => checks[i]);
		return live ? {
			stack: live,
			source: "cookie"
		} : {
			stack: null,
			source: null
		};
	}
	const probed = await probeStacks();
	return {
		stack: probed,
		source: probed ? "probe" : null
	};
}
async function publishStack(stack) {
	if (!stack) return;
	const { sfmcStack } = await storageGet("local", "sfmcStack");
	if (sfmcStack !== stack) await storageSet("local", {
		sfmcStack: stack,
		sfmcStackTs: Date.now()
	});
}
async function resolveAndPublish() {
	const resolved = await resolveStack();
	if (resolved.stack) await publishStack(resolved.stack);
	return resolved;
}
async function forgetStack(stack) {
	if (!stack) return;
	console.warn("[Toolkit:SW] Forgetting stack after an auth failure:", stack);
	for (const fn of forgetHooks) fn(stack);
	for (const [k, ctx] of Object.entries(sfmcSession)) if (ctx?.stackKey === stack) delete sfmcSession[k];
	const { sfmcStack } = await storageGet("local", "sfmcStack");
	if (sfmcStack === stack) await storageRemove("local", ["sfmcStack", "sfmcStackTs"]);
	const { lastActiveStack } = await storageGet("session", "lastActiveStack");
	if (lastActiveStack?.stack === stack) await storageRemove("session", "lastActiveStack");
}
async function getStacks() {
	const [candidates, resolved, { stackOverride }] = await Promise.all([
		collectStackCandidates(),
		resolveStack(),
		storageGet("local", "stackOverride")
	]);
	return {
		candidates,
		resolved: resolved.stack,
		source: resolved.source,
		override: stackOverride || null
	};
}
async function setStackOverride(value) {
	const stack = value ? String(value).trim().toLowerCase() : null;
	if (stack && !STACK_RE.test(stack)) return { error: "A stack looks like s10 or 401." };
	if (stack) await storageSet("local", { stackOverride: stack });
	else await storageRemove("local", "stackOverride");
	const r = await resolveAndPublish();
	return {
		stack: r.stack,
		source: r.source
	};
}
function captureContext(ctx) {
	if (!ctx?.hostname) return;
	sfmcSession[ctx.hostname] = ctx;
	if (ctx.stackKey) sfmcSession["_stack_" + ctx.stackKey] = ctx;
}
async function getSession(stackKey) {
	if (stackKey && sfmcSession["_stack_" + stackKey]) return { session: sfmcSession["_stack_" + stackKey] };
	const { stack } = await resolveAndPublish();
	if (!stack) return { session: null };
	return { session: sfmcSession["_stack_" + stack] || { stackKey: stack } };
}
// src/background/csrf.js
var MAX_AGE$2 = 84e4;
var csrfCache = {};
async function restoreCsrfTokens() {
	storageRemove("local", "_csrfTokens");
	const { _csrfTokens: stored = {} } = await storageGet("session", "_csrfTokens");
	const now = Date.now();
	for (const [stack, entry] of Object.entries(stored)) if (entry?.csrfToken && now - (entry.csrfCapturedAt || 0) < MAX_AGE$2) csrfCache[stack] = {
		token: entry.csrfToken,
		capturedAt: entry.csrfCapturedAt
	};
}
async function rememberCsrf(stack, token) {
	if (!stack || !token || token === csrfCache[stack]?.token) return;
	const capturedAt = Date.now();
	csrfCache[stack] = {
		token,
		capturedAt
	};
	const { _csrfTokens: stored = {} } = await storageGet("session", "_csrfTokens");
	stored[stack] = {
		csrfToken: token,
		csrfCapturedAt: capturedAt
	};
	await storageSet("session", { _csrfTokens: stored });
}
function getCoreCsrf(stack) {
	const entry = stack && csrfCache[stack];
	return entry && Date.now() - entry.capturedAt < MAX_AGE$2 ? entry.token : null;
}
function sniffCsrf(details) {
	if (!details.requestHeaders) return;
	const m = details.url.match(/(?:mc|members)\.([^.]+)\.exacttarget\.com/);
	if (!m) return;
	const h = details.requestHeaders.find((x) => x.name.toLowerCase() === "x-csrf-token");
	if (h?.value) rememberCsrf(m[1], h.value);
}
async function getAppCsrf(rawUrl, cookieName = "_csrf") {
	try {
		const cookie = await getCookie({
			url: new URL(rawUrl).origin + "/",
			name: cookieName
		});
		if (!cookie?.value) return null;
		try {
			return decodeURIComponent(cookie.value);
		} catch {
			return cookie.value;
		}
	} catch {
		return null;
	}
}
// src/utils/policyKeys.js
var POLICY_KEYS = [
	"disableHistory",
	"disableShare",
	"disableFeedback",
	"disableFeedbackMetadata",
	"disableScreenshots",
	"disableContacts",
	"disableDiagramforce",
	"disableAiAssist",
	"disableDnsLookup"
];
/** Only `true` turns a policy on; anything else (missing, false, a string) leaves it off. */
function normalizePolicy(raw) {
	return Object.fromEntries(POLICY_KEYS.map((k) => [k, raw?.[k] === true]));
}
// src/background/policy.js
var current = normalizePolicy({});
var ready = null;
function read() {
	return new Promise((resolve) => {
		try {
			chrome.storage.managed.get(null, (r) => {
				chrome.runtime.lastError;
				current = normalizePolicy(r || {});
				resolve(current);
			});
		} catch {
			resolve(current);
		}
	});
}
function watchPolicy() {
	ready = read();
	try {
		chrome.storage.onChanged.addListener((_, area) => {
			if (area === "managed") ready = read();
		});
	} catch {}
}
/** The policy as last read (for synchronous webRequest listeners). */
var policyNow = () => current;
/** The policy, once it has been read. */
async function getPolicy() {
	if (!ready) ready = read();
	return ready;
}
// src/background/pageHeaders.js
var MAX_AGE$1 = 18e5;
var KEY$1 = "_cbPageHeaders";
var cache$3 = {};
/** contactsmeta paths that need the page's headers. */
function needsPageHeaders(url) {
	return /\/contactsmeta\/fuelapi\/(contacts(-internal)?\/|legacy\/v1\/beta\/contact\/)/i.test(String(url || ""));
}
var stackOf$1 = (url) => String(url || "").match(/^https:\/\/mc\.([^.]+)\.marketingcloudapps\.com\/contactsmeta\//i)?.[1]?.toLowerCase() || null;
async function restorePageHeaders() {
	try {
		const { [KEY$1]: stored = {} } = await storageGet("session", KEY$1);
		const now = Date.now();
		for (const [stack, e] of Object.entries(stored)) if (e && now - (e.capturedAt || 0) < MAX_AGE$1) cache$3[stack] = e;
	} catch {}
}
async function persist$1() {
	try {
		await storageSet("session", { [KEY$1]: cache$3 });
	} catch {}
}
/**
* webRequest.onBeforeSendHeaders listener for contactsmeta. Only SFMC's own page
* requests count (the extension's requests have no tab, or the extension's origin).
*/
function sniffPageHeaders(details) {
	if (!details?.requestHeaders || details.tabId < 0) return;
	if (policyNow().disableContacts) return;
	if (String(details.initiator || "").startsWith("chrome-extension://")) return;
	const stack = stackOf$1(details.url);
	if (!stack) return;
	const get = (n) => details.requestHeaders.find((h) => h.name.toLowerCase() === n)?.value || null;
	const authorization = get("authorization");
	const csrf = get("x-csrf-token");
	const tz = get("tz");
	if (!authorization && !csrf) return;
	const prev = cache$3[stack] || {};
	const now = Date.now();
	cache$3[stack] = {
		authorization: authorization || prev.authorization || null,
		csrf: csrf || prev.csrf || null,
		tz: tz || prev.tz || null,
		capturedAt: now,
		csrfAt: csrf ? now : prev.csrfAt || 0
	};
	persist$1();
}
/** The headers to send for a contacts call, or null when none are known. */
function pageHeadersFor(stack) {
	const e = stack && cache$3[stack];
	if (!e || Date.now() - e.capturedAt > MAX_AGE$1) return null;
	const h = { "X-Requested-With": "XMLHttpRequest" };
	if (e.authorization) h.Authorization = e.authorization;
	if (e.csrf && Date.now() - e.csrfAt < MAX_AGE$1) h["X-CSRF-Token"] = e.csrf;
	if (e.tz) h.tz = e.tz;
	return h;
}
function dropPageHeaders(stack) {
	delete cache$3[stack];
	persist$1();
}
var pageTiming = {
	waitMs: 2e4,
	pollMs: 500
};
var inFlight$3 = /* @__PURE__ */ new Map();
/**
* Opens Contact Builder's All Contacts screen in an inactive tab until its requests
* have shown the headers (a CSRF token when `needCsrf`), then closes it. Resolves to
* the headers or null. One at a time per stack.
*/
function capturePageHeaders(stack, { needCsrf = true } = {}) {
	if (inFlight$3.has(stack)) return inFlight$3.get(stack);
	const ok = () => {
		const h = pageHeadersFor(stack);
		return h && h.Authorization && (!needCsrf || h["X-CSRF-Token"]) ? h : null;
	};
	const p = (async () => {
		if (ok()) return ok();
		const tab = await createTab({
			url: `https://mc.${stack}.marketingcloudapps.com/contactsmeta/admin.html#admin/all-contacts`,
			active: false
		});
		if (!tab) return null;
		try {
			const deadline = Date.now() + pageTiming.waitMs;
			while (Date.now() < deadline) {
				await new Promise((r) => setTimeout(r, pageTiming.pollMs));
				if (ok()) return ok();
			}
			return pageHeadersFor(stack);
		} finally {
			removeTab(tab.id);
		}
	})().finally(() => inFlight$3.delete(stack));
	inFlight$3.set(stack, p);
	return p;
}
// src/background/jbCsrf.js
var MAX_AGE = 18e5;
var KEY = "_jbCsrf";
var cache$2 = {};
var stackOf = (url) => String(url || "").match(/^https:\/\/jbinteractions\.([^.]+)\.marketingcloudapps\.com\//i)?.[1]?.toLowerCase() || null;
async function restoreJbCsrf() {
	try {
		const { [KEY]: stored = {} } = await storageGet("session", KEY);
		const now = Date.now();
		for (const [stack, e] of Object.entries(stored)) if (e?.token && now - (e.at || 0) < MAX_AGE) cache$2[stack] = e;
	} catch {}
}
async function persist() {
	try {
		await storageSet("session", { [KEY]: cache$2 });
	} catch {}
}
/** webRequest.onBeforeSendHeaders listener for jbinteractions: only SFMC's own page requests count. */
function sniffJbCsrf(details) {
	if (!details?.requestHeaders || details.tabId < 0) return;
	if (String(details.initiator || "").startsWith("chrome-extension://")) return;
	const stack = stackOf(details.url);
	if (!stack) return;
	const token = details.requestHeaders.find((h) => h.name.toLowerCase() === "x-csrf-token")?.value;
	if (!token || token === cache$2[stack]?.token) {
		if (token) cache$2[stack].at = Date.now();
		return;
	}
	cache$2[stack] = {
		token,
		at: Date.now()
	};
	persist();
}
function jbCsrfFor(stack) {
	const e = stack && cache$2[stack];
	return e && Date.now() - e.at < MAX_AGE ? e.token : null;
}
function dropJbCsrf(stack) {
	delete cache$2[stack];
	persist();
}
var jbTiming = {
	waitMs: 3e4,
	pollMs: 500
};
var inFlight$2 = /* @__PURE__ */ new Map();
/** Opens Journey Builder in an inactive tab until a token has been seen, then closes it. One at a time per stack. */
function captureJbCsrf(stack) {
	if (inFlight$2.has(stack)) return inFlight$2.get(stack);
	const p = (async () => {
		if (jbCsrfFor(stack)) return jbCsrfFor(stack);
		const tab = await createTab({
			url: `https://mc.${stack}.exacttarget.com/cloud/#app/Journey%20Builder`,
			active: false
		});
		if (!tab) return null;
		try {
			const deadline = Date.now() + jbTiming.waitMs;
			while (Date.now() < deadline) {
				await new Promise((r) => setTimeout(r, jbTiming.pollMs));
				if (jbCsrfFor(stack)) return jbCsrfFor(stack);
			}
			return null;
		} finally {
			removeTab(tab.id);
		}
	})().finally(() => inFlight$2.delete(stack));
	inFlight$2.set(stack, p);
	return p;
}
// src/background/mcaToken.js
var mintTiming = {
	timeoutMs: 1e4,
	backoffMs: 12e4
};
var tokenCache = {};
var inFlight$1 = {};
var failedAt$1 = {};
var pendingByTab = /* @__PURE__ */ new Map();
var onMintFailure = () => {};
function setOnMintFailure(fn) {
	onMintFailure = fn;
}
function mintBackoff(stack) {
	return Date.now() - (failedAt$1[stack] || 0) < mintTiming.backoffMs;
}
function isMcaTokenReady(stack) {
	const cached = stack && tokenCache[stack];
	return !!cached && Date.now() < cached.expiresAt;
}
function dropMcaToken(stack) {
	delete tokenCache[stack];
}
function decodeJwtExp(jwt) {
	try {
		const payload = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
		const json = JSON.parse(atob(payload + "===".slice((payload.length + 3) % 4)));
		return json.exp ? json.exp * 1e3 : null;
	} catch {
		return null;
	}
}
function handleCapturedToken(sender, accessToken) {
	const resolve = pendingByTab.get(sender?.tab?.id);
	if (resolve) resolve(accessToken || null);
}
function mint(stack) {
	if (inFlight$1[stack]) return inFlight$1[stack];
	const promise = new Promise((resolve) => {
		let settled = false;
		let tabId = null;
		const finish = (token) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			if (tabId != null) {
				pendingByTab.delete(tabId);
				removeTab(tabId);
			}
			resolve(token);
		};
		const timer = setTimeout(() => {
			console.warn("[Toolkit:SW] MCA token mint timed out for stack:", stack);
			finish(null);
		}, mintTiming.timeoutMs);
		createTab({
			url: `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/update-token.json`,
			active: false
		}).then((tab) => {
			if (!tab) return finish(null);
			tabId = tab.id;
			if (settled) return removeTab(tabId);
			pendingByTab.set(tabId, finish);
		});
	}).finally(() => {
		delete inFlight$1[stack];
	});
	inFlight$1[stack] = promise;
	return promise;
}
async function getMcaToken(stack) {
	if (!stack) return null;
	if (isMcaTokenReady(stack)) return tokenCache[stack].accessToken;
	if (mintBackoff(stack)) return null;
	const accessToken = await mint(stack);
	if (!accessToken) {
		failedAt$1[stack] = Date.now();
		onMintFailure(stack);
		return null;
	}
	delete failedAt$1[stack];
	tokenCache[stack] = {
		accessToken,
		expiresAt: (decodeJwtExp(accessToken) || Date.now() + 6e5) - 3e4
	};
	return accessToken;
}
// src/background/sessions.js
var LOGIN_REQUIRED = "SFMC_LOGIN_REQUIRED";
var SESSION_UNAVAILABLE = "SFMC_SESSION_UNAVAILABLE";
var timing = {
	pollMs: 1e3,
	landingTimeoutMs: 15e3,
	cooldownMs: 3e4
};
var LOGIN_COOKIES = [{
	host: (s) => `mc.${s}.exacttarget.com`,
	name: "platformAuthCookie"
}, {
	host: (s) => `members.${s}.exacttarget.com`,
	name: "ETAuthCookie"
}];
var inFlight = /* @__PURE__ */ new Map();
var failedAt = /* @__PURE__ */ new Map();
var starting = /* @__PURE__ */ new Set();
var warmedAt = /* @__PURE__ */ new Map();
var SfmcAuthError = class extends Error {
	constructor(code, message) {
		super(message);
		this.code = code;
	}
};
async function isLoggedIn(stack) {
	for (const c of LOGIN_COOKIES) if (await getCookie({
		url: `https://${c.host(stack)}/`,
		name: c.name
	})) return true;
	return false;
}
async function probeSession(app, stack) {
	try {
		return (await fetch(app.probeUrl(stack), {
			credentials: "include",
			redirect: "manual"
		})).status === 200;
	} catch {
		return false;
	}
}
function landingTimeout(app, landingUrl) {
	const t = typeof app.landingTimeoutMs === "function" ? app.landingTimeoutMs(landingUrl) : app.landingTimeoutMs;
	return Number.isFinite(t) && t > 0 ? t : timing.landingTimeoutMs;
}
function unavailable(app, stack) {
	const hint = app.sessionHint ? ` ${app.sessionHint}` : "";
	return new SfmcAuthError(SESSION_UNAVAILABLE, `Could not start a ${app.name} session on stack ${stack}.${hint}`);
}
async function tryLanding(app, stack, landingUrl) {
	const tab = await createTab({
		url: landingUrl,
		active: false
	});
	if (!tab) return false;
	try {
		const deadline = Date.now() + landingTimeout(app, landingUrl);
		while (Date.now() < deadline) {
			await delay(timing.pollMs);
			if (await probeSession(app, stack)) return true;
		}
		return false;
	} finally {
		removeTab(tab.id);
	}
}
function ensureSession(app, stack, { onLoggedOut } = {}) {
	const key = `${stack}:${app.id}`;
	if (inFlight.has(key)) return inFlight.get(key);
	const last = failedAt.get(key);
	if (last && Date.now() - last < timing.cooldownMs) return Promise.reject(unavailable(app, stack));
	const promise = (async () => {
		if (await probeSession(app, stack)) return;
		if (!await isLoggedIn(stack)) {
			await onLoggedOut?.(stack);
			throw new SfmcAuthError(LOGIN_REQUIRED, `Not logged in to Marketing Cloud on stack ${stack}.`);
		}
		for (const url of app.landings(stack)) if (await tryLanding(app, stack, url)) return;
		throw unavailable(app, stack);
	})().then(() => {
		failedAt.delete(key);
	}).catch((err) => {
		failedAt.set(key, Date.now());
		throw err;
	}).finally(() => {
		inFlight.delete(key);
	});
	inFlight.set(key, promise);
	return promise;
}
async function sessionStatus(stack) {
	const loggedIn = await isLoggedIn(stack);
	return {
		stack,
		loggedIn,
		apps: await Promise.all(SFMC_APPS.filter((app) => !app.onDemand).map(async (app) => ({
			id: app.id,
			name: app.name,
			ok: loggedIn && await probeSession(app, stack),
			starting: starting.has(`${stack}:${app.id}`)
		})))
	};
}
async function connectApp(stack, appId, opts) {
	const app = findApp(appId);
	if (!app) throw new Error(`Unknown SFMC app: ${appId}`);
	const key = `${stack}:${app.id}`;
	const last = failedAt.get(key);
	if (app.retryGapMs && last && Date.now() - last < app.retryGapMs) throw unavailable(app, stack);
	failedAt.delete(key);
	await ensureSession(app, stack, opts);
}
/**
* Starts the app sessions that are missing, but only when at least one app already
* has a session: then the user is logged in and SFMC answers, so the rest can be
* started. With none, the user is most likely not logged in and opening tabs would
* not help. Apps are started one at a time (one inactive tab each), at most once
* every 10 minutes per stack unless `force`.
* @returns {{ skipped?: string, started?: string[], failed?: string[] }}
*/
async function warmUpMissing(stack, { force = false, onLoggedOut } = {}) {
	if (!stack) return { skipped: "no stack" };
	const last = warmedAt.get(stack);
	if (!force && last && Date.now() - last < 6e5) return { skipped: "recently" };
	const status = await sessionStatus(stack);
	if (!status.loggedIn) return { skipped: "not logged in" };
	if (!status.apps.some((a) => a.ok)) return { skipped: "no app session" };
	warmedAt.set(stack, Date.now());
	const missing = status.apps.filter((a) => !a.ok).map((a) => findApp(a.id));
	const started = [];
	const failed = [];
	for (const app of missing) starting.add(`${stack}:${app.id}`);
	try {
		for (const app of missing) try {
			failedAt.delete(`${stack}:${app.id}`);
			await ensureSession(app, stack, { onLoggedOut });
			started.push(app.id);
		} catch (e) {
			failed.push(app.id);
			if (e.code === "SFMC_LOGIN_REQUIRED") break;
		} finally {
			starting.delete(`${stack}:${app.id}`);
		}
	} finally {
		for (const app of missing) starting.delete(`${stack}:${app.id}`);
	}
	return {
		started,
		failed
	};
}
// src/background/fetchProxy.js
/**
* SFMC's own HTML error pages (IIS "403 Not Authorized") turned into their title,
* so a message reads "Not Authorized" instead of a page of markup (feedback #67).
*/
var HTML_ENTITIES = {
	"&quot;": "\"",
	"&#34;": "\"",
	"&#39;": "'",
	"&apos;": "'",
	"&lt;": "<",
	"&gt;": ">",
	"&nbsp;": " ",
	"&amp;": "&"
};
var decodeEntities = (s) => s.replace(/&(quot|#34|#39|apos|lt|gt|nbsp|amp);/g, (m) => HTML_ENTITIES[m]);
function errorText(text) {
	const t = String(text ?? "");
	if (!/^\s*</.test(t)) return t;
	const pick = (tag) => decodeEntities((t.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"))?.[1] || "").replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
	const h1 = pick("h1");
	const detail = pick("h3");
	if (detail && (!h1 || /^\d{3}$/.test(h1))) return detail;
	return pick("title") || h1 || detail || "SFMC returned an error page";
}
var SfmcApiError = class extends Error {
	constructor(status, text) {
		super(`SFMC API error ${status}: ${errorText(text).substring(0, 300)}`);
		this.status = status;
	}
};
function isWebPage(text) {
	return /^\s*(<!DOCTYPE html|<html)/i.test(String(text ?? ""));
}
var needsSession = (res) => res.status === 401 || res.type === "opaqueredirect" || res.webPage;
function appInfo(app, stack) {
	const cloud = stack ? `https://mc.${stack}.exacttarget.com/cloud/` : null;
	if (!app) return {
		id: null,
		name: "Marketing Cloud",
		url: cloud
	};
	const url = stack && app.landings(stack).find((u) => u.includes(".exacttarget.com/cloud/")) || cloud;
	return {
		id: app.id,
		name: app.name,
		url
	};
}
async function send(url, method, body, headers) {
	const opts = {
		method,
		credentials: "include",
		redirect: "manual",
		headers: {
			"Content-Type": "application/json",
			...headers
		}
	};
	if (body != null) opts.body = typeof body === "string" ? body : JSON.stringify(body);
	try {
		const r = await fetch(url, opts);
		const body = await r.text().catch(() => "");
		return {
			ok: r.ok,
			status: r.status,
			type: r.type,
			headers: r.headers,
			body,
			webPage: r.ok && isWebPage(body)
		};
	} catch (err) {
		return {
			ok: false,
			status: 0,
			type: "error",
			headers: new Headers(),
			body: err.message,
			webPage: false
		};
	}
}
async function authHeaders({ url, stack, family, app, mutating }) {
	const headers = {};
	if (family === "mca" && stack && needsPageHeaders(url)) {
		let ph = pageHeadersFor(stack);
		if (!ph?.Authorization || mutating && !ph["X-CSRF-Token"]) ph = await capturePageHeaders(stack, { needCsrf: mutating }) || ph;
		if (ph?.Authorization) return { ...ph };
	}
	if (family === "core") {
		const csrf = mutating && getCoreCsrf(stack);
		if (csrf) headers["X-CSRF-Token"] = csrf;
	} else if (family === "mca") {
		if (app?.bearer) {
			const token = await getMcaToken(stack);
			if (token) headers.Authorization = `Bearer ${token}`;
		}
		if (mutating && app?.id === "journeyBuilder") {
			const token = jbCsrfFor(stack) || await captureJbCsrf(stack);
			if (token) headers["X-CSRF-Token"] = token;
			headers["X-Requested-With"] = "XMLHttpRequest";
		} else if (mutating) {
			const csrf = await getAppCsrf(url, app?.csrfCookie || "_csrf");
			if (csrf) headers["X-CSRF-Token"] = csrf;
		}
	}
	return headers;
}
async function sfmcFetch(request) {
	const { stack, app } = resolveUrl(request.url);
	try {
		return await fetchWithSession(request);
	} catch (err) {
		if (err && typeof err === "object" && !err.app) err.app = appInfo(app, stack);
		throw err;
	}
}
async function fetchWithSession({ url, method = "GET", body = null, bootstrap = true }) {
	const target = {
		url,
		...resolveUrl(url),
		mutating: method !== "GET" && method !== "HEAD"
	};
	const { stack, family, app } = target;
	let headers = await authHeaders(target);
	let res = await send(url, method, body, headers);
	if (app?.id === "journeyBuilder" && target.mutating && /EBADCSRFTOKEN|invalid csrf token/i.test(res.body || "")) {
		dropJbCsrf(stack);
		headers = await authHeaders(target);
		res = await send(url, method, body, headers);
	} else if (res.status === 403 && family === "mca" && headers["X-CSRF-Token"]) {
		if (needsPageHeaders(url) && headers["X-Requested-With"]) dropPageHeaders(stack);
		headers = await authHeaders(target);
		res = await send(url, method, body, headers);
	}
	if (needsSession(res) && app?.bearer && headers.Authorization) {
		dropMcaToken(stack);
		headers = await authHeaders(target);
		if (headers.Authorization) res = await send(url, method, body, headers);
	}
	if (needsSession(res) && app && stack && bootstrap) {
		await ensureSession(app, stack, { onLoggedOut: forgetStack });
		headers = await authHeaders(target);
		res = await send(url, method, body, headers);
	}
	if (res.webPage) throw new SfmcAuthError(SESSION_UNAVAILABLE, `${app?.name || "SFMC"} sent a web page (its login) instead of data, so it has no session.`);
	if (needsSession(res)) {
		await forgetStack(stack);
		throw new SfmcAuthError(LOGIN_REQUIRED, "SFMC session expired (401). Please log in to SFMC in any tab, then try again.");
	}
	const text = res.body;
	if (family === "core" && stack) {
		const fresh = res.headers?.get?.("x-csrf-token");
		if (fresh) rememberCsrf(stack, fresh);
	}
	if (!res.ok) throw new SfmcApiError(res.status, text);
	if (!text) return null;
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
}
// src/utils/activityVersions.js
var ACTIVITY_SAVER_SETTING = "_activitySaverEnabled";
var ACTIVITY_MAX_SETTING = "_activityMaxVersions";
var KINDS = {
	query: {
		segment: "queries",
		contentField: "queryText",
		idField: "queryDefinitionId",
		label: "SQL Query"
	},
	script: {
		segment: "scripts",
		contentField: "script",
		idField: "ssjsActivityId",
		label: "Script"
	}
};
var recordKey = (kind, id) => `activity_${kind}_${String(id).toLowerCase()}`;
var ID = "[0-9a-zA-Z-]{6,}";
var VERBS = /* @__PURE__ */ new Set([
	"validate",
	"validation",
	"run",
	"start",
	"stop",
	"pause",
	"perform",
	"actions",
	"action",
	"search",
	"copy",
	"preview",
	"test",
	"execute",
	"status",
	"create",
	"update",
	"delete",
	"list",
	"query",
	"queries",
	"script",
	"scripts"
]);
/** Whether a path segment looks like an activity id: a GUID, or has a digit and is not a known verb. */
function looksLikeActivityId(id) {
	const s = String(id || "");
	if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s)) return true;
	return s.length >= 6 && /\d/.test(s) && /^[0-9a-zA-Z-]+$/.test(s) && !VERBS.has(s.toLowerCase());
}
var QUERY_SEGMENTS = [
	"queries",
	"query",
	"queryactivities",
	"querydefinitions",
	"querydefinition"
];
var SCRIPT_SEGMENTS = [
	"scripts",
	"script",
	"ssjs",
	"ssjsactivities",
	"ssjsactivity",
	"scriptactivities"
];
var SAVE_RE = new RegExp(`^https://[^/]+\\.([^./]+)\\.(?:marketingcloudapps|exacttarget)\\.com/(?:[^?#]*/)?AutomationStudioFuel3/(?:[^?#]*/)?(${[...QUERY_SEGMENTS, ...SCRIPT_SEGMENTS].join("|")})/(${ID})/?(?:[?#].*)?$`, "i");
var WRITE_METHODS = /* @__PURE__ */ new Set([
	"PATCH",
	"PUT",
	"POST"
]);
/** { kind, id, stack } for an Automation Studio save of a query or script, else null. */
function matchActivitySave(url, method) {
	if (!WRITE_METHODS.has(String(method || "").toUpperCase())) return null;
	const m = String(url || "").match(SAVE_RE);
	if (!m || !looksLikeActivityId(m[3])) return null;
	return {
		kind: QUERY_SEGMENTS.includes(m[2].toLowerCase()) ? "query" : "script",
		id: m[3],
		stack: m[1].toLowerCase()
	};
}
/** The JSON body of a webRequest requestBody (raw bytes or form fields), or null. */
function decodeRequestBody(requestBody) {
	try {
		if (requestBody?.raw?.length) {
			const parts = requestBody.raw.filter((p) => p?.bytes).map((p) => new Uint8Array(p.bytes));
			const size = parts.reduce((n, p) => n + p.length, 0);
			const all = new Uint8Array(size);
			let at = 0;
			for (const p of parts) {
				all.set(p, at);
				at += p.length;
			}
			const parsed = JSON.parse(new TextDecoder("utf-8").decode(all));
			return parsed && typeof parsed === "object" ? parsed : null;
		}
		if (requestBody?.formData) {
			const f = requestBody.formData;
			const one = (k) => Array.isArray(f[k]) ? f[k][0] : f[k];
			return Object.fromEntries(Object.keys(f).map((k) => [k, one(k)]));
		}
	} catch {}
	return null;
}
var UPDATE_TYPES$1 = {
	0: "Overwrite",
	1: "Update",
	2: "Append"
};
/**
* The fields worth keeping from a query or script object (a save body or the GET of
* the activity). Returns null when it holds no SQL or script.
*/
function pickActivity(kind, obj) {
	if (!obj || typeof obj !== "object" || !KINDS[kind]) return null;
	const cf = KINDS[kind].contentField;
	const o = typeof obj[cf] === "string" ? obj : [obj[kind], obj.definition].find((w) => w && typeof w[cf] === "string") || obj;
	const content = o[KINDS[kind].contentField];
	if (typeof content !== "string") return null;
	const out = {
		name: typeof o.name === "string" ? o.name : "",
		key: o.key || o.customerKey || "",
		content
	};
	if (kind === "query") {
		out.targetName = o.targetName || o.targetDataExtensionName || "";
		out.targetKey = o.targetKey || "";
		const t = o.targetUpdateTypeName ?? UPDATE_TYPES$1[o.targetUpdateTypeId];
		out.targetUpdateType = typeof t === "string" ? t : "";
	}
	return out;
}
var sameField = (x, y) => !x || !y || x === y;
var sameContent = (a, b) => !!a && !!b && a.content === b.content && sameField(a.name, b.name) && sameField(a.targetName, b.targetName) && sameField(a.targetUpdateType, b.targetUpdateType);
/**
* Adds versions (oldest first in `incoming`) to a record. A version identical to the
* newest stored one is skipped. At most `max` versions are kept (newest first).
* Returns the new versions array and how many were added.
*/
function addVersions(existing, incoming, max = 50) {
	const versions = Array.isArray(existing) ? [...existing] : [];
	let added = 0;
	for (const v of incoming) {
		if (!v || typeof v.content !== "string") continue;
		if (sameContent(versions[0], v)) continue;
		versions.unshift(v);
		added++;
	}
	const limit = Number.isFinite(Number(max)) && Number(max) > 0 ? Math.floor(Number(max)) : 50;
	return {
		versions: versions.slice(0, limit),
		added
	};
}
function makeVersion(picked, { savedAt, source, stack }) {
	return {
		versionId: `v_${savedAt}_${source === "before-save" ? "b" : "s"}`,
		savedAt,
		source,
		stack: stack || null,
		...picked
	};
}
/** Where to read (GET) or write back (PATCH) one activity through Automation Studio. */
function activityUrl(kind, stack, id) {
	return `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi/automation/v1/${KINDS[kind].segment}/${encodeURIComponent(id)}`;
}
/** The versions key of a described activity (utils/activityTypes.js), or null. */
function versionsKeyFor(objectTypeId, details) {
	const id = Number(objectTypeId) === 300 ? details?.queryDefinitionId : Number(objectTypeId) === 423 ? details?.ssjsActivityId : null;
	if (!id) return null;
	return recordKey(Number(objectTypeId) === 300 ? "query" : "script", id);
}
// src/utils/activityStart.js
var START_TYPES = {
	73: {
		path: "dataextracts",
		idField: "dataExtractDefinitionId",
		label: "Data Extract",
		tested: true
	},
	43: {
		path: "imports",
		idField: "importDefinitionId",
		label: "Import File",
		tested: false
	},
	423: {
		path: "scripts",
		idField: "ssjsActivityId",
		label: "Script",
		tested: false
	}
};
/** { typeId, id, label, tested } for an activity record that can be started, else null. */
function startTarget(typeId, record) {
	const t = START_TYPES[typeId];
	if (!t || !record) return null;
	const id = record[t.idField] || (record._fromStep ? record.activityObjectId : null);
	return id ? {
		typeId: Number(typeId),
		id: String(id),
		label: t.label,
		tested: t.tested
	} : null;
}
// src/utils/activityTypes.js
var ACTIVITY_TYPES = {
	33: "SMS",
	42: "Send Email",
	43: "Import File",
	45: "Group Refresh",
	53: "File Transfer",
	73: "Data Extract",
	84: "Report",
	300: "SQL Query",
	303: "Filter",
	423: "Script",
	425: "ELT Activity",
	426: "Refresh Counts",
	427: "Build Audience",
	467: "Wait",
	614: "Life Cycle",
	615: "Count Audience",
	724: "MC List Refresh",
	725: "MC Send Message",
	726: "MC Import File",
	736: "Mobile Push",
	749: "Interaction Studio Event",
	771: "Salesforce Send",
	783: "Group Connect",
	952: "Journey Entry",
	1e3: "Data Verification",
	1010: "Thunderhead Refresh",
	1101: "Interaction Studio Decision",
	1701: "Predictive Intelligence",
	3700: "Contacts BU Mapping"
};
var activityTypeLabel = (id) => ACTIVITY_TYPES[id] || `Type ${id}`;
var UPDATE_TYPES = {
	1: "Add Only",
	2: "Update Only",
	3: "Add and Update",
	4: "Overwrite"
};
var IMPORT_UPDATE_TYPES = {
	0: "Add and Update",
	1: "Add Only",
	2: "Update Only",
	3: "Merge",
	4: "Overwrite",
	5: "Column based"
};
var IMPORT_DESTINATIONS = {
	13: "List",
	310: "Data Extension",
	584: "Mobile Subscription",
	613: "Mobile Push"
};
var AS_BASE = (stack) => `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi`;
var ENDPOINTS = {
	300: "queries",
	303: "filters",
	423: "scripts",
	73: "dataextracts",
	53: "filetransfers",
	1e3: "dataverifications",
	43: "imports",
	425: "eltactivities"
};
/** URL of an activity's full record, or null when SFMC has none (Wait, Journey, ...). */
function activityEndpoint(stack, activity) {
	const id = encodeURIComponent(activity.activityObjectId ?? "");
	if (ENDPOINTS[activity.objectTypeId]) return `${AS_BASE(stack)}/automation/v1/${ENDPOINTS[activity.objectTypeId]}/${id}`;
	if (activity.objectTypeId === 42) return `${AS_BASE(stack)}/messaging-internal/v1/emailsenddefinition/${id}`;
	return null;
}
var AS_LINK = (stack, kind, typeId, id) => id ? `https://mc.${stack}.exacttarget.com/cloud/#app/Automation%20Studio/AutomationStudioFuel3/%23${kind}/${typeId}/${encodeURIComponent(id)}` : null;
function automationStudioUrl(stack) {
	return `https://mc.${stack}.exacttarget.com/cloud/#app/Automation%20Studio/AutomationStudioFuel3/`;
}
function formatValue(v) {
	if (v === null || v === void 0 || v === "") return "—";
	if (typeof v === "boolean") return v ? "Yes" : "No";
	if (typeof v === "object") return JSON.stringify(v);
	return String(v);
}
var humanize = (k) => String(k).replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
var STEP_FIELDS = /* @__PURE__ */ new Set([
	"objectTypeId",
	"activityObjectId",
	"displayOrder",
	"isPaused",
	"isActive",
	"serializedObject",
	"_fromStep",
	"additionalStepDetails"
]);
function rest(details, used) {
	return Object.entries(details || {}).filter(([k]) => !used.has(k) && !STEP_FIELDS.has(k)).map(([k, v]) => [humanize(k), formatValue(v)]);
}
function stepNote(d) {
	if (!d._fromStep) return null;
	if (d._fromStep === "error") return "SFMC did not return the details of this activity (see the error); this is what the automation step holds. A 404 usually means the activity was deleted.";
	return "SFMC has no API for the details of this activity type; this is what the automation step holds.";
}
function kvTable(title, obj, extra = false) {
	if (!obj || typeof obj !== "object") return null;
	return {
		title,
		columns: ["Property", "Value"],
		rows: Object.entries(obj).map(([k, v]) => [humanize(k), formatValue(v)]),
		extra
	};
}
function nvtTable(title, list, extra = false) {
	if (!Array.isArray(list)) return null;
	return {
		title,
		columns: [
			"Name",
			"Type",
			"Value"
		],
		rows: list.map((x) => [
			formatValue(x?.name),
			formatValue(x?.type),
			formatValue(x?.value)
		]),
		extra
	};
}
function build$1(details, typeId, stack, spec) {
	const d = details || {};
	const used = /* @__PURE__ */ new Set(["name"]);
	const pick = ([label, f]) => {
		if (typeof f === "string") used.add(f);
		return [label, formatValue(typeof f === "function" ? f(d) : d[f])];
	};
	const main = (spec.main || []).map(pick);
	const extra = (spec.extra || []).map(pick);
	if (spec.code?.key) used.add(spec.code.key);
	for (const k of spec.alsoUsed || []) used.add(k);
	const codeText = spec.code ? d[spec.code.key] : null;
	return {
		typeLabel: activityTypeLabel(typeId),
		title: d.name || activityTypeLabel(typeId),
		link: spec.link ? spec.link(d, stack) : null,
		note: spec.noNote ? null : stepNote(d),
		main,
		extra: [...extra, ...rest(d, used)],
		code: codeText ? {
			label: spec.code.label,
			text: String(codeText),
			lang: spec.code.lang
		} : null,
		tables: (spec.tables ? spec.tables(d) : []).filter(Boolean),
		deRefs: Object.fromEntries(Object.entries(spec.deRefs ? spec.deRefs(d) : {}).filter(([, r]) => r && typeof r.name === "string" && r.name.trim()).map(([label, r]) => [label, {
			name: r.name,
			id: r.id || null,
			key: r.key || null
		}])),
		run: spec.run ? spec.run(d) : null,
		versionsKey: spec.versionsKey ? spec.versionsKey(d) : null,
		start: startTarget(typeId, d)
	};
}
var SPECS = {
	300: {
		link: (d, s) => AS_LINK(s, "ActivityDetails", 300, d.queryDefinitionId),
		main: [
			["Description", "description"],
			["Target", "targetName"],
			["Update type", (d) => d.targetUpdateTypeName || UPDATE_TYPES[d.targetUpdateTypeId]]
		],
		extra: [
			["Query definition ID", "queryDefinitionId"],
			["Target ID", "targetId"],
			["Target key", "targetKey"],
			["Target description", "targetDescription"],
			["Update type ID", "targetUpdateTypeId"],
			["Created", "createdDate"],
			["Modified", "modifiedDate"],
			["Frozen", "isFrozen"]
		],
		alsoUsed: ["targetUpdateTypeName"],
		code: {
			key: "queryText",
			label: "SQL",
			lang: "sql"
		},
		deRefs: (d) => ({ Target: {
			name: d.targetName,
			id: d.targetId,
			key: d.targetKey
		} }),
		run: (d) => d.queryDefinitionId ? {
			queryDefinitionId: d.queryDefinitionId,
			sql: d.queryText || "",
			targetName: d.targetName || "",
			updateType: d.targetUpdateTypeName || UPDATE_TYPES[d.targetUpdateTypeId] || ""
		} : null,
		versionsKey: (d) => versionsKeyFor(300, d)
	},
	423: {
		link: (d, s) => AS_LINK(s, "ActivityModal", 423, d.ssjsActivityId),
		main: [["Description", "description"]],
		extra: [
			["Key", "key"],
			["Script activity ID", "ssjsActivityId"],
			["Created", "createdDate"],
			["Modified", "modifiedDate"]
		],
		code: {
			key: "script",
			label: "Script",
			lang: "javascript"
		},
		versionsKey: (d) => versionsKeyFor(423, d)
	},
	303: {
		link: (d, s) => AS_LINK(s, "ActivityModal", 303, d.filterActivityId),
		main: [
			["Description", "description"],
			["Source", (d) => d.sourceObjectName || d.sourceObjectId],
			["Result", (d) => d.resultDEName || d.destinationObjectName || d.resultDEKey]
		],
		deRefs: (d) => ({ Result: {
			name: d.resultDEName || d.destinationObjectName,
			key: d.resultDEKey
		} }),
		tables: (d) => [kvTable("Filter definition", d.additionalStepDetails)]
	},
	73: {
		link: (d, s) => AS_LINK(s, "ActivityModal", 73, d.dataExtractDefinitionId),
		main: [
			["Description", "description"],
			["File spec", "fileSpec"],
			["Interval type", "intervalType"]
		],
		extra: [
			["Data extract definition ID", "dataExtractDefinitionId"],
			["Data extract type ID", "dataExtractTypeId"],
			["Created", "createdDate"],
			["Created by", "createdBy"],
			["Modified", "modifiedDate"],
			["Modified by", "modifiedBy"]
		],
		alsoUsed: ["dataFields"],
		tables: (d) => [nvtTable("Data fields", d.dataFields)]
	},
	53: {
		link: (d, s) => AS_LINK(s, "ActivityDetails", 53, d.id),
		main: [
			["File spec", (d) => d.additionalStepDetails?.fileSpec ?? d.fileSpec],
			["Upload", (d) => d.additionalStepDetails?.isUpload ?? d.isUpload],
			["Encrypted", (d) => d.additionalStepDetails?.isEncrypted],
			["PGP encrypted", (d) => d.additionalStepDetails?.isPgp],
			["Compressed", (d) => d.additionalStepDetails?.isCompressed],
			["File spec localized", (d) => d.additionalStepDetails?.isFileSpecLocalized]
		],
		extra: [
			["ID", "id"],
			["Customer key", "customerKey"],
			["Location ID", (d) => d.additionalStepDetails?.fileTransferLocationId],
			["Created", "createdDate"],
			["Modified", "modifiedDate"]
		]
	},
	43: {
		link: (d, s) => AS_LINK(s, "ActivityDetails", 43, d.importDefinitionId),
		main: [
			["Description", "description"],
			["File spec", "fileSpec"],
			["File naming pattern", "fileNamingPattern"],
			["Field mapping type", "fieldMappingType"],
			["Destination type", (d) => IMPORT_DESTINATIONS[d.destinationObjectTypeId] || d.destinationObjectTypeId],
			["Target", (d) => d.destinationName || d.targetDataExtension?.name || d.targetDataExtension || (Number(d.destinationObjectTypeId) === 13 && d.destinationId ? `List ID ${d.destinationId}` : "")],
			["Update type", (d) => IMPORT_UPDATE_TYPES[d.updateTypeId] ?? d.updateTypeId]
		],
		extra: [
			["Allow errors", "allowErrors"],
			["Customer key", "customerKey"],
			["Created", "createdDate"],
			["Modified", "modifiedDate"],
			["Date format locale", "dateFormatLocale"],
			["Delete file", "deleteFile"],
			["Destination ID", "destinationObjectId"],
			["File transfer location ID", "fileTransferLocationId"],
			["File type", "fileType"],
			["Notification email", "notificationEmailAddress"],
			["Send email notification", "sendEmailNotification"],
			["Subscriber import type ID", "subscriberImportTypeId"],
			["Max file age (hours)", "maxFileAgeHours"],
			["Max import frequency (hours)", "maxImportFrequencyHours"],
			["Standard quoted strings", "standardQuotedStrings"]
		],
		alsoUsed: [
			"destinationObjectTypeId",
			"targetDataExtension",
			"destinationName",
			"updateTypeId",
			"fieldMappings",
			"importDefinitionId"
		],
		deRefs: (d) => d.destinationObjectTypeId != null && Number(d.destinationObjectTypeId) !== 310 ? {} : { "Target": typeof d.targetDataExtension === "object" && d.targetDataExtension ? {
			name: d.targetDataExtension.name,
			id: d.targetDataExtension.id,
			key: d.targetDataExtension.customerKey ?? d.targetDataExtension.key
		} : { name: typeof d.targetDataExtension === "string" ? d.targetDataExtension : "" } },
		tables: (d) => [nvtTable("Field mappings", d.fieldMappings, true)]
	},
	42: { main: [
		["Description", "description"],
		["Subject", "emailSubject"],
		["From name", "fromName"],
		["From email", "fromEmail"],
		["Send classification", "sendClassificationName"]
	] },
	1e3: { main: [
		["Description", "description"],
		["Condition", "verificationCondition"],
		["Verification type", "verificationType"]
	] },
	467: {
		noNote: true,
		extra: [["ID", "id"], ["Activity object ID", "activityObjectId"]],
		tables: (d) => [Array.isArray(d.serializedObject) ? nvtTable("Wait settings", d.serializedObject) : d.serializedObject ? {
			title: "Wait settings",
			columns: ["Value"],
			rows: [[formatValue(d.serializedObject)]]
		} : null]
	},
	952: {
		noNote: true,
		main: [
			["Activity object ID", "activityObjectId"],
			["Activity ID", "id"],
			["Display order", "displayOrder"]
		]
	},
	425: {
		link: (d, s) => d.eltActivityId ? automationStudioUrl(s) : null,
		main: [["Description", "description"], ["Status", "status"]],
		extra: [
			["ELT activity ID", "eltActivityId"],
			["Key", "key"],
			["Status ID", "statusId"],
			["Category ID", "categoryId"],
			["Created", "createdDate"],
			["Created by", "createdBy"],
			["Modified", "modifiedDate"],
			["Modified by", "modifiedBy"]
		]
	}
};
/** Display data for one activity's details (see the top of this file). */
function describeActivity(objectTypeId, details, stack) {
	const spec = SPECS[objectTypeId];
	if (spec) return build$1(details, objectTypeId, stack, spec);
	const d = details || {};
	const all = Object.entries(d).filter(([k]) => k !== "name" && !STEP_FIELDS.has(k)).map(([k, v]) => [humanize(k), formatValue(v)]);
	return {
		typeLabel: activityTypeLabel(objectTypeId),
		title: d.name || activityTypeLabel(objectTypeId),
		link: null,
		note: stepNote(d),
		main: all,
		extra: [],
		code: null,
		tables: [],
		deRefs: {},
		run: null
	};
}
// src/background/automationSummary.js
var AS$2 = (stack) => `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi`;
var CODE_MAX = 6e3;
var ROWS_MAX = 12;
var cell = (v) => v == null ? "" : typeof v === "object" ? v.text ?? v.label ?? JSON.stringify(v) : String(v);
/** Plain rows and code for the panel (it renders text only). */
function panelActivity(desc, raw) {
	return {
		type: desc.typeLabel,
		title: desc.title || raw?.name || "",
		rows: (desc.main || []).map(([k, v]) => [String(k), cell(v).trim()]).filter(([, v]) => v !== "" && v !== "—" && v !== "-").slice(0, ROWS_MAX),
		code: desc.code?.text ? {
			text: String(desc.code.text).slice(0, CODE_MAX),
			cut: String(desc.code.text).length > CODE_MAX
		} : null,
		note: desc.note || null
	};
}
async function automationSummary(stack, id, fetcher = sfmcFetch) {
	if (!/^s\d+$/i.test(String(stack || "")) || !/^[A-Za-z0-9-]+$/.test(String(id || ""))) throw new Error("Not an automation.");
	const d = await fetcher({ url: `${AS$2(stack)}/automation/v1/automations/${encodeURIComponent(id)}` });
	const steps = (d?.steps || []).map((s) => ({
		name: s.name || "",
		activities: (s.activities || []).map((a) => ({
			raw: a,
			out: null
		}))
	}));
	const all = steps.flatMap((s) => s.activities);
	let next = 0;
	async function worker() {
		while (next < all.length) {
			const item = all[next++];
			const a = item.raw;
			try {
				const url = activityEndpoint(stack, a);
				const details = url ? await fetcher({ url }) : {
					...a,
					_fromStep: true
				};
				item.out = panelActivity(describeActivity(a.objectTypeId, details, stack), a);
			} catch (e) {
				item.out = {
					...panelActivity(describeActivity(a.objectTypeId, {
						...a,
						_fromStep: true
					}, stack), a),
					error: e.message
				};
			}
		}
	}
	await Promise.all(Array.from({ length: Math.min(4, all.length) }, worker));
	return {
		name: d?.name || "",
		status: d?.status ?? null,
		lastRunTime: d?.lastRunTime || null,
		lastRunStatus: d?.lastRunStatus || null,
		schedule: d?.schedule ? {
			status: d.schedule.scheduleStatus ?? null,
			next: d.schedule.scheduledTime || null
		} : null,
		type: d?.type || null,
		key: d?.key || null,
		description: d?.description || "",
		steps: steps.map((s) => ({
			name: s.name,
			activities: s.activities.map((x) => x.out)
		}))
	};
}
// src/utils/savedAssets.js
var CLOUD_PAGE_ASSET_TYPE_IDS = [
	240,
	241,
	242,
	243,
	244,
	245,
	247,
	248,
	249
];
var SAVED_ASSET_KINDS = {
	email: {
		kind: "email",
		prefix: "email_",
		base: "/emails",
		list: "/emails/saved",
		noun: "email",
		nouns: "emails",
		title: "Saved Emails",
		setting: "_emailSaverEnabled",
		app: "Content Builder",
		appPath: "Content%20Builder",
		reopen: "Reload the email in Content Builder to see it."
	},
	cloudpage: {
		kind: "cloudpage",
		prefix: "cloudpage_",
		base: "/cloudpages/saved",
		list: "/cloudpages/saved",
		noun: "CloudPage",
		nouns: "CloudPages",
		title: "Saved CloudPages",
		setting: "_cloudPageSaverEnabled",
		app: "CloudPages",
		appPath: "CloudPages",
		reopen: "Reopen it in CloudPages to see it, and publish it again to put it live."
	}
};
var SAVE_FAILED_KEY = "_savedAssetNotKept";
/** 'email' | 'cloudpage' | null for a saved asset (the body SFMC's editor sends). */
function savedAssetKind(asset) {
	if ((asset?.assetType?.name || "").toLowerCase().includes("email")) return "email";
	const id = Number(asset?.assetType?.id);
	const name = (asset?.assetType?.name || "").toLowerCase();
	if (CLOUD_PAGE_ASSET_TYPE_IDS.includes(id) || /landingpage|webpage|coderesource/.test(name)) return "cloudpage";
	return null;
}
var savedAssetKey = (kind, assetId) => `${SAVED_ASSET_KINDS[kind].prefix}${assetId}`;
/**
* A saved record without the copies of its content (feedback #1086). Before 2.0.23 each
* save kept the content three times: compileAsset on the record, compileAsset on the
* version and the assetBody the version is reverted from. compileAsset is made from the
* assetBody when it is needed, so only versions without an assetBody (saved before
* versions were kept) keep theirs. Returns the same object when nothing changes.
*/
function slimSavedRecord(rec) {
	if (!rec || typeof rec !== "object" || !Array.isArray(rec.versions) || !rec.versions.length) return rec;
	let changed = false;
	const versions = rec.versions.map((v) => {
		if (!v?.compileAsset || !v.assetBody) return v;
		changed = true;
		const { compileAsset, ...rest } = v;
		return rest;
	});
	const next = {
		...rec,
		versions
	};
	if ("compileAsset" in next && versions.some((v) => v?.assetBody || v?.compileAsset)) {
		delete next.compileAsset;
		changed = true;
	}
	return changed ? next : rec;
}
// src/background/storageRoom.js
var BUDGET_BYTES = 9437184;
var sizeOf = (v) => JSON.stringify(v ?? null).length;
var isSavedAssetKey = (key) => key.startsWith("email_") || key.startsWith("cloudpage_");
/**
* Which email versions to drop so that `over` bytes are freed: oldest first across
* every email, never an email's newest version. Returns { [key]: record without them }
* for the records that change, and the bytes freed.
*/
function trimEmailVersions(all, over) {
	const candidates = [];
	for (const [key, rec] of Object.entries(all || {})) {
		if (!isSavedAssetKey(key) || !Array.isArray(rec?.versions)) continue;
		rec.versions.slice(1).forEach((v) => candidates.push({
			key,
			v,
			at: v?.savedAt || 0,
			bytes: sizeOf(v)
		}));
	}
	candidates.sort((a, b) => a.at - b.at);
	const drop = /* @__PURE__ */ new Map();
	let freed = 0;
	for (const c of candidates) {
		if (freed >= over) break;
		if (!drop.has(c.key)) drop.set(c.key, /* @__PURE__ */ new Set());
		drop.get(c.key).add(c.v);
		freed += c.bytes;
	}
	const changed = {};
	for (const [key, gone] of drop) changed[key] = {
		...all[key],
		versions: all[key].versions.filter((v) => !gone.has(v))
	};
	return {
		changed,
		freed
	};
}
function bytesInUse() {
	return new Promise((resolve) => {
		try {
			chrome.storage.local.getBytesInUse(null, (b) => resolve(b || 0));
		} catch {
			resolve(0);
		}
	});
}
/** { [key]: slimmer record } for the saved emails and CloudPages that kept copies of their content. */
function slimSavedAssets(all) {
	const changed = {};
	for (const [key, rec] of Object.entries(all || {})) {
		if (!isSavedAssetKey(key)) continue;
		const next = slimSavedRecord(rec);
		if (next !== rec) changed[key] = next;
	}
	return changed;
}
/** Removes the extra copies from every saved email and CloudPage. Returns how many records changed. */
async function slimStoredAssets() {
	const changed = slimSavedAssets(await storageGet("local", null));
	if (Object.keys(changed).length) await storageSet("local", changed);
	return Object.keys(changed).length;
}
/** Frees space for `need` more bytes by dropping old email versions. Returns the bytes freed. */
async function makeRoom(need = 0) {
	const over = await bytesInUse() + need - BUDGET_BYTES;
	if (over <= 0) return 0;
	let all = await storageGet("local", null);
	let slimmed = 0;
	const slim = slimSavedAssets(all);
	if (Object.keys(slim).length) {
		await storageSet("local", slim);
		slimmed = Object.entries(slim).reduce((n, [k, v]) => n + sizeOf(all[k]) - sizeOf(v), 0);
		all = {
			...all,
			...slim
		};
	}
	if (over - slimmed <= 0) return slimmed;
	const { changed, freed } = trimEmailVersions(all, over - slimmed);
	if (Object.keys(changed).length) await storageSet("local", changed);
	if (freed) console.warn(`[Toolkit:SW] Storage nearly full: removed old Saved Emails versions (${Math.round(freed / 1024)} KB).`);
	return slimmed + freed;
}
// src/background/businessUnit.js
var cache$1 = {};
var TTL = 6e4;
function toBusinessUnit(d) {
	if (!d?.name) return null;
	return {
		name: d.name,
		accountId: d.accountId ?? d.id ?? d.memberId ?? null
	};
}
async function fetchCurrentBusinessUnit(stack) {
	const hit = cache$1[stack];
	if (hit && Date.now() - hit.ts < TTL) return hit.bu;
	const res = await fetch(`https://mc.${stack}.exacttarget.com/cloud/fuelapi/platform-internal/v1/accounts/@current`, {
		credentials: "include",
		redirect: "manual"
	});
	if (res.status !== 200) return null;
	const bu = toBusinessUnit(await res.json());
	cache$1[stack] = {
		ts: Date.now(),
		bu
	};
	return bu;
}
var QUERY_STUDIO_CREATE_URLS = ["https://*.herokuapp.com/query/create"];
/** True for Query Studio's own hosts: querystudio.herokuapp.com, querystudio2-<id>.herokuapp.com. */
function isQueryStudioUrl(url) {
	try {
		const u = new URL(url);
		return u.protocol === "https:" && /^querystudio[a-z0-9-]*\.herokuapp\.com$/i.test(u.hostname);
	} catch {
		return false;
	}
}
// src/background/capture.js
var decoder = new TextDecoder("utf-8");
async function blinkIcon() {
	try {
		chrome.action.setIcon({ path: "/images/icon48x48-off.png" });
		await delay(5e3);
		chrome.action.setIcon({ path: "/images/icon48x48.png" });
	} catch {}
}
async function saveRecords(records) {
	blinkIcon();
	await storageSet("local", records);
}
async function renameQuery(id, name) {
	const rec = (await storageGet("local", id))[id];
	if (rec) await storageSet("local", { [id]: {
		...rec,
		name
	} });
}
async function tagBusinessUnit(id) {
	try {
		const { stack } = await resolveStack();
		if (!stack) return;
		const bu = await fetchCurrentBusinessUnit(stack);
		if (!bu) return;
		const rec = (await storageGet("local", id))[id];
		if (!rec || rec.businessUnit?.name) return;
		await storageSet("local", { [id]: {
			...rec,
			businessUnit: {
				...rec.businessUnit || {},
				...bu
			}
		} });
	} catch (e) {
		console.warn("[Toolkit:SW] Could not tag the business unit:", e?.message);
	}
}
async function captureQueryStudio(details) {
	if (details.method !== "POST" || !details.requestBody?.raw?.[0]?.bytes || !isQueryStudioUrl(details.url)) return;
	if ((await getPolicy()).disableHistory) return;
	if ((await storageGet("local", ["_saveQueryStudio"]))["_saveQueryStudio"] === false) return;
	let queryText;
	try {
		queryText = JSON.parse(decoder.decode(new Uint8Array(details.requestBody.raw[0].bytes))).querytext;
	} catch {
		return;
	}
	if (!queryText) return;
	const ts = details.timeStamp;
	const id = "sql_" + ts;
	await saveRecords({ [id]: {
		id,
		queryText,
		timeStamp: ts,
		url: details.url,
		name: new Date(ts).toDateString() + " " + new Date(ts).toLocaleTimeString(),
		isFavourite: false
	} });
	await tagBusinessUnit(id);
}
var emailSaver = {
	enabled: true,
	debounceMs: 5e3
};
var cloudPageSaver = { enabled: true };
var lastSavedAt = {};
async function loadEmailSaverPrefs() {
	applyEmailSaverPrefs(await storageGet("local", [
		"_emailSaverEnabled",
		"_emailSaveDebounce",
		"_cloudPageSaverEnabled"
	]));
}
function applyEmailSaverPrefs(prefs) {
	if ("_emailSaverEnabled" in prefs) emailSaver.enabled = prefs._emailSaverEnabled !== false;
	if ("_cloudPageSaverEnabled" in prefs) cloudPageSaver.enabled = prefs._cloudPageSaverEnabled !== false;
	if ("_emailSaveDebounce" in prefs) {
		const s = prefs._emailSaveDebounce;
		emailSaver.debounceMs = typeof s === "number" && s >= 0 ? s * 1e3 : 5e3;
	}
}
async function captureEmail(details) {
	if (details.method !== "PUT") return;
	if ((await getPolicy()).disableHistory) return;
	if (!details.requestBody?.raw?.[0]?.bytes) return;
	let jsonStr, asset;
	try {
		jsonStr = decoder.decode(new Uint8Array(details.requestBody.raw[0].bytes));
		asset = JSON.parse(jsonStr);
	} catch {
		return;
	}
	const kind = savedAssetKind(asset);
	if (!kind || kind === "email" && !emailSaver.enabled || kind === "cloudpage" && !cloudPageSaver.enabled) return;
	const assetId = asset.id || Number(details.url.split("/").pop());
	const now = Date.now();
	if (emailSaver.debounceMs > 0 && now - (lastSavedAt[assetId] || 0) < emailSaver.debounceMs) return;
	lastSavedAt[assetId] = now;
	const key = savedAssetKey(kind, assetId);
	const stack = details.url.match(/(?:content-builder|cloud-pages)\.([^.]+)\.marketingcloudapps\.com/)?.[1] || null;
	const saveOrigin = (() => {
		try {
			return new URL(details.url).origin;
		} catch {
			return null;
		}
	})();
	const assetBody = JSON.parse(jsonStr);
	if (assetBody.views) assetBody.views = {
		...asset.views.subjectline ? { subjectline: asset.views.subjectline } : {},
		...asset.views.preheader ? { preheader: asset.views.preheader } : {},
		...asset.views.html ? { html: asset.views.html } : {}
	};
	delete assetBody.thumbnail;
	const subject = asset.views?.subjectline?.content || "";
	const version = {
		versionId: `v_${now}`,
		savedAt: now,
		subject,
		name: asset.name || `Email ${assetId}`,
		status: asset.status?.name || "Draft",
		categoryName: asset.category?.name || "",
		assetBody,
		stack,
		saveOrigin
	};
	await makeRoom(JSON.stringify(version).length);
	const prev = (await storageGet("local", key))[key];
	const record = {
		id: key,
		assetId: Number(assetId),
		customerKey: asset.customerKey || "",
		name: asset.name || `${kind === "email" ? "Email" : "CloudPage"} ${assetId}`,
		kind,
		assetTypeName: asset.assetType?.name || "",
		assetTypeDisplayName: asset.assetType?.displayName || "",
		status: asset.status?.name || "Draft",
		categoryId: asset.category?.id || null,
		categoryName: asset.category?.name || "",
		subject,
		ownerName: asset.owner?.name || "",
		ownerEmail: asset.owner?.email || "",
		memberId: asset.memberId || null,
		enterpriseId: asset.enterpriseId || null,
		createdDate: asset.createdDate || null,
		modifiedDate: asset.modifiedDate || null,
		isFavourite: prev?.isFavourite || false,
		timeStamp: prev?.timeStamp || now,
		versions: [version, ...Array.isArray(prev?.versions) ? prev.versions : []].slice(0, 10)
	};
	const slim = slimSavedRecord(record);
	blinkIcon();
	const error = await storageSetChecked("local", { [key]: slim });
	if (error) {
		console.warn(`[Toolkit:SW] Could not keep the save of "${record.name}": ${error}`);
		await storageSet("session", { [SAVE_FAILED_KEY]: {
			kind,
			key,
			name: record.name,
			at: now,
			error
		} });
	} else await storageRemove("session", SAVE_FAILED_KEY);
}
// src/utils/openTab.js
/** Tab properties that place a new tab right after `tab` in its window. */
function nextTo(tab, props = {}) {
	if (!tab || typeof tab.index !== "number") return { ...props };
	const out = {
		...props,
		index: tab.index + 1
	};
	if (tab.windowId !== void 0) out.windowId = tab.windowId;
	if (tab.id !== void 0) out.openerTabId = tab.id;
	return out;
}
// src/background/deepLinks.js
var WATCH_FOR = 18e4;
/** True when `now` is the stack's SFMC shell without the deep part of `wanted`. */
function lostDeepLink(wanted, now) {
	try {
		const w = new URL(wanted);
		const n = new URL(now);
		if (n.host !== w.host || !n.pathname.startsWith("/cloud")) return false;
		const want = decodeURIComponent(w.hash);
		const have = decodeURIComponent(n.hash);
		return want.length > 1 && have !== want && !have.startsWith(want);
	} catch {
		return false;
	}
}
function openSfmcLink(url, fromTab = null) {
	return new Promise((resolve) => {
		let tabId = null;
		let restored = false;
		let leftShell = false;
		const stop = () => {
			try {
				chrome.tabs.onUpdated.removeListener(onUpdated);
			} catch {}
		};
		const onUpdated = (id, info, tab) => {
			if (id !== tabId || restored) return;
			const now = info.url || tab?.url || "";
			if (!now) return;
			if (!now.startsWith(url) && !lostDeepLink(url, now)) leftShell = true;
			if (info.status === "complete" && lostDeepLink(url, tab?.url || now) && (leftShell || tab?.url !== url)) {
				restored = true;
				stop();
				chrome.tabs.update(id, { url }, () => void chrome.runtime.lastError);
			}
		};
		try {
			chrome.tabs.onUpdated.addListener(onUpdated);
			chrome.tabs.create(nextTo(fromTab, { url }), (tab) => {
				if (chrome.runtime.lastError || !tab) {
					stop();
					resolve({ ok: false });
					return;
				}
				tabId = tab.id;
				setTimeout(stop, WATCH_FOR);
				resolve({ ok: true });
			});
		} catch {
			stop();
			resolve({ ok: false });
		}
	});
}
function sharedQueryRecords(records, senderUrl) {
	if (!String(senderUrl || "").startsWith("https://sfmc-share-worker.mathes-btech.workers.dev/share/")) return null;
	const entries = Object.entries(records || {});
	if (entries.length !== 1) return null;
	const [id, r] = entries[0];
	if (!/^sql_\d+$/.test(id) || !r || typeof r.queryText !== "string" || !r.queryText.trim() || r.queryText.length > 1e5) return null;
	const timeStamp = Number(id.slice(4));
	return { [id]: {
		id,
		queryText: r.queryText,
		timeStamp,
		url: String(senderUrl).split(/[?#]/)[0],
		name: String(r.name || "").slice(0, 200) || new Date(timeStamp).toDateString(),
		isFavourite: false
	} };
}
// src/background/senders.js
var CONTENT_TYPES = /* @__PURE__ */ new Set([
	"SFMC_CONTEXT_CAPTURED",
	"MCA_TOKEN_CAPTURED",
	"OPEN_APP",
	"DASHBOARD_SUMMARY",
	"IMPORT_SHARED_QUERY",
	"SFMC_FETCH",
	"AUTOMATION_SUMMARY"
]);
var AUTOMATION_GET = /^https:\/\/mc\.[a-z0-9]+\.marketingcloudapps\.com\/AutomationStudioFuel3\/fuelapi\/automation\/v1\/automations\/[A-Za-z0-9%-]+$/;
/** Whether `message` from `sender` may be handled. */
function messageAllowed(message, sender, extensionOrigin) {
	if (sender?.url && String(sender.url).startsWith(extensionOrigin)) return true;
	const type = message?.type;
	if (!CONTENT_TYPES.has(type)) return false;
	if (type === "AUTOMATION_SUMMARY") return /^s\d+$/i.test(String(message.stack || "")) && /^[A-Za-z0-9-]{1,64}$/.test(String(message.id || ""));
	if (type === "SFMC_FETCH") return String(message.method || "GET").toUpperCase() === "GET" && !message.body && AUTOMATION_GET.test(String(message.url || ""));
	return true;
}
// src/background/updates.js
var UPDATE_KEY = "_updateAvailable";
function note(version) {
	if (version) chrome.storage.local.set({ [UPDATE_KEY]: {
		version,
		at: Date.now()
	} });
}
function watchForUpdates() {
	chrome.runtime.onUpdateAvailable?.addListener((details) => note(details?.version));
	chrome.runtime.onInstalled?.addListener(() => chrome.storage.local.remove([UPDATE_KEY, "sfmcqs_analytics_cid"]));
	try {
		chrome.runtime.requestUpdateCheck?.((status, details) => {
			chrome.runtime.lastError;
			if (status === "update_available") note(details?.version);
		});
	} catch {}
}
// src/utils/format.js
/**
* SFMC's joined-up status names in words: "PausedSchedule" -> "Paused schedule",
* "ScheduledToPublish" -> "Scheduled to publish" (live test, 2026-11-08). Anything
* else is returned as is.
*/
function statusWords(v) {
	const s = String(v ?? "");
	return /^[A-Z][a-z]+(?:[A-Z][a-z]+)+$/.test(s) ? s.replace(/(?!^)([A-Z])/g, (c) => ` ${c.toLowerCase()}`) : s;
}
// src/utils/watches.js
var WATCHES_KEY = "toolkit_watches";
var NOTICES_KEY = "toolkit_watch_notices";
var NOTIFY_KEY = "toolkit_watch_desktop";
var DEFAULT_ON = {
	paused: true,
	activated: true,
	runs: false,
	fails: true
};
var JOURNEY_DEFAULT_ON = {
	paused: true,
	activated: true,
	edited: false
};
var watchType = (w) => w?.type === "journey" ? "journey" : "automation";
var STATUS_NAMES = {
	"-1": "Error",
	0: "Build error",
	1: "Building",
	2: "Ready",
	3: "Running",
	4: "Paused",
	5: "Stopped",
	6: "Scheduled",
	7: "Awaiting trigger",
	8: "Inactive trigger"
};
function automationStatusName(v) {
	if (v == null || v === "") return "";
	const n = Number(v);
	if (Number.isInteger(n) && String(n) === String(v).trim() && STATUS_NAMES[n] != null) return STATUS_NAMES[n];
	return statusWords(v);
}
/** Whether a watch belongs to the business unit `mid` (watches without a BU yet count everywhere). */
var watchHere = (w, mid) => !w?.mid || !mid || String(w.mid) === String(mid);
var isPausedLike = (s) => /^(paused|stopped)$/i.test(s);
var isActiveLike = (s) => /^(scheduled|awaiting trigger|running)$/i.test(s);
var isFailure = (s) => /error|fail/i.test(String(s || ""));
var time$1 = (v) => {
	const t = Date.parse(v || "");
	return Number.isNaN(t) ? 0 : t;
};
/**
* Notices for the change from `prev` to `cur` ({ status, lastRunTime, lastRunStatus }),
* for the kinds switched on in `on`. No notices without a previous snapshot.
*/
function diffAutomation(prev, cur, on = DEFAULT_ON) {
	if (!prev || !cur) return [];
	const out = [];
	const was = automationStatusName(prev.status);
	const now = automationStatusName(cur.status);
	if (now && was && now !== was) {
		if (isPausedLike(now) && on.paused) out.push({
			kind: "paused",
			text: `is now ${now} (was ${was})`
		});
		else if (isActiveLike(now) && !isActiveLike(was) && on.activated) out.push({
			kind: "activated",
			text: `is now ${now} (was ${was})`
		});
	}
	if (time$1(cur.lastRunTime) > time$1(prev.lastRunTime)) {
		if (isFailure(cur.lastRunStatus) && on.fails) out.push({
			kind: "fails",
			text: `run failed${cur.lastRunStatus ? ` (${cur.lastRunStatus})` : ""}`
		});
		else if (on.runs) out.push({
			kind: "runs",
			text: `ran${cur.lastRunStatus ? `: ${cur.lastRunStatus}` : ""}`
		});
	}
	return out;
}
/** What a journey watch compares: status, version and last change. */
var journeySnapshot = (j) => ({
	status: j?.status ?? null,
	version: j?.version ?? null,
	modifiedDate: j?.modifiedDate ?? null
});
/** Notices for a journey's change from `prev` to `cur` ({ status, version, modifiedDate }). */
function diffJourney(prev, cur, on = JOURNEY_DEFAULT_ON) {
	if (!prev || !cur) return [];
	const out = [];
	const was = String(prev.status || "");
	const now = String(cur.status || "");
	if (now && was && now !== was) {
		if (/^(paused|stopped)$/i.test(now) && on.paused) out.push({
			kind: "paused",
			text: `is now ${now} (was ${was})`
		});
		else if (/^published$/i.test(now) && on.activated) out.push({
			kind: "activated",
			text: `is now ${now} (was ${was})`
		});
	}
	if (on.edited) {
		if (Number(cur.version) > Number(prev.version)) out.push({
			kind: "edited",
			text: `has a new version (${cur.version}, was ${prev.version})`
		});
		else if (cur.modifiedDate && prev.modifiedDate && time$1(cur.modifiedDate) > time$1(prev.modifiedDate)) out.push({
			kind: "edited",
			text: "was changed"
		});
	}
	return out;
}
/** Adds notices (newest first), keeping at most MAX_NOTICES. */
function addNotices(list, watch, changes, now = Date.now()) {
	const target = watchType(watch) === "journey" ? {
		type: "journey",
		journeyId: watch.id
	} : { automationId: watch.id };
	return [...changes.map((c, i) => ({
		id: `${now.toString(36)}${i}${Math.random().toString(36).slice(2, 6)}`,
		at: now,
		stack: watch.stack,
		...target,
		name: watch.name,
		kind: c.kind,
		text: c.text,
		read: false
	})), ...Array.isArray(list) ? list : []].slice(0, 50);
}
var unreadCount = (list) => Array.isArray(list) ? list.filter((n) => !n.read).length : 0;
// src/background/watches.js
var AS$1 = (stack) => `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi`;
var JB$1 = (stack) => `https://jbinteractions.${stack}.marketingcloudapps.com/fuelapi/interaction/v1`;
var CHECKED_KEY = "toolkit_watch_checked";
var PAGE_INTERVAL = 9e5;
var running$1 = /* @__PURE__ */ new Set();
async function currentMid(stack) {
	try {
		const d = await sfmcFetch({ url: `https://mc.${stack}.exacttarget.com/cloud/fuelapi/platform-internal/v1/accounts/@current` });
		const mid = d?.accountId ?? d?.id ?? d?.memberId;
		return mid != null ? String(mid) : null;
	} catch {
		return null;
	}
}
async function journeySnap(stack, w) {
	const d = await sfmcFetch({ url: `${JB$1(stack)}/interactions/${w.key ? `key:${encodeURIComponent(w.key)}` : encodeURIComponent(w.id)}` });
	return {
		...journeySnapshot(d),
		name: d?.name || w.name,
		id: d?.id || w.id
	};
}
async function snapshot(stack, w) {
	const d = await sfmcFetch({ url: `${AS$1(stack)}/automation/v1/automations/${encodeURIComponent(w.id)}` });
	const snap = {
		status: d?.status ?? null,
		lastRunTime: d?.lastRunTime ?? null,
		lastRunStatus: d?.lastRunStatus ?? null,
		name: d?.name || w.name
	};
	if (!snap.lastRunStatus && snap.lastRunTime && snap.lastRunTime === w.last?.lastRunTime) snap.lastRunStatus = w.last?.lastRunStatus ?? null;
	if (snap.lastRunTime && !snap.lastRunStatus) try {
		const at = Date.parse(snap.lastRunTime);
		const t = Number.isNaN(at) ? Date.now() : at;
		const day = (ms) => new Date(ms).toISOString().slice(0, 10);
		const runs = await sfmcFetch({ url: `${AS$1(stack)}/legacy/v1/beta/automations/automation/instance/?definition_id=${encodeURIComponent(w.id)}&$top=1&begin_date=${day(t - 864e5)}&end_date=${day(t + 864e5)}&order_by=${encodeURIComponent("StartTime desc")}&to_server_time=1` });
		const r = (runs?.entry || runs?.items || [])[0];
		snap.lastRunStatus = r?.status ?? r?.statusName ?? r?.StatusName ?? null;
	} catch {}
	return snap;
}
async function updateBadge(list) {
	const n = unreadCount(list ?? (await storageGet("local", ["toolkit_watch_notices"]))["toolkit_watch_notices"]);
	try {
		await chrome.action?.setBadgeText?.({ text: n ? String(Math.min(n, 99)) : "" });
		if (n) await chrome.action?.setBadgeBackgroundColor?.({ color: "#d03b3b" });
	} catch {}
}
/** Checks the stack's watched automations; `force` skips the 15-minute wait. Returns { checked, notices }. */
async function checkWatches(stack, { force = false } = {}) {
	if (!stack || running$1.has(stack)) return {
		checked: 0,
		notices: 0
	};
	const store = await storageGet("local", [
		WATCHES_KEY,
		NOTICES_KEY,
		CHECKED_KEY,
		NOTIFY_KEY
	]);
	const watches = store["toolkit_watches"] || {};
	const mine = Object.entries(watches).filter(([, w]) => w.stack === stack);
	const checkedAt = store[CHECKED_KEY] || {};
	if (!mine.length || !force && Date.now() - (checkedAt[stack] || 0) < PAGE_INTERVAL) return {
		checked: 0,
		notices: 0
	};
	running$1.add(stack);
	try {
		const mid = await currentMid(stack);
		let notices = store["toolkit_watch_notices"] || [];
		const fresh = [];
		let checked = 0;
		for (const [k, w] of mine) {
			if (!watchHere(w, mid)) continue;
			checked++;
			try {
				if (watchType(w) === "journey") {
					const cur = await journeySnap(stack, w);
					const changes = diffJourney(w.last, cur, w.on);
					const watch = {
						...w,
						name: cur.name,
						id: cur.id
					};
					if (changes.length) {
						notices = addNotices(notices, watch, changes);
						fresh.push(...changes.map((c) => `${cur.name} ${c.text}`));
					}
					watches[k] = {
						...w,
						...mid ? { mid } : {},
						name: cur.name,
						latestId: cur.id,
						last: journeySnapshot(cur),
						checkedAt: Date.now(),
						error: void 0,
						notFound: void 0
					};
					continue;
				}
				const cur = await snapshot(stack, w);
				const changes = diffAutomation(w.last, cur, w.on);
				if (changes.length) {
					notices = addNotices(notices, {
						...w,
						name: cur.name
					}, changes);
					fresh.push(...changes.map((c) => `${cur.name} ${c.text}`));
				}
				watches[k] = {
					...w,
					name: cur.name,
					last: {
						status: cur.status,
						statusName: automationStatusName(cur.status),
						lastRunTime: cur.lastRunTime,
						lastRunStatus: cur.lastRunStatus
					},
					...mid ? { mid } : {},
					checkedAt: Date.now(),
					error: void 0,
					notFound: void 0
				};
			} catch (e) {
				if (e?.status === 404 || /error 404/.test(e?.message || "")) watches[k] = {
					...w,
					notFound: true,
					error: void 0,
					checkedAt: Date.now()
				};
				else watches[k] = {
					...w,
					error: e?.message || String(e),
					notFound: void 0,
					checkedAt: Date.now()
				};
			}
		}
		await chrome.storage.local.set({
			[WATCHES_KEY]: watches,
			[NOTICES_KEY]: notices,
			[CHECKED_KEY]: {
				...checkedAt,
				[stack]: Date.now()
			}
		});
		await updateBadge(notices);
		if (fresh.length && store["toolkit_watch_desktop"] && chrome.notifications?.create) chrome.notifications.create({
			type: "basic",
			iconUrl: chrome.runtime.getURL("images/icon128x128.png"),
			title: "Marketing Cloud Toolkit: watched automations and journeys",
			message: fresh.slice(0, 3).join("\n") + (fresh.length > 3 ? `\n+${fresh.length - 3} more` : "")
		});
		return {
			checked,
			notices: fresh.length
		};
	} finally {
		running$1.delete(stack);
	}
}
// src/utils/summaries.js
var time = (v) => {
	const t = Date.parse(v || "");
	return Number.isNaN(t) ? 0 : t;
};
function countBy(list, keyOf) {
	const m = /* @__PURE__ */ new Map();
	for (const x of list) {
		const k = keyOf(x) || "Unknown";
		m.set(k, (m.get(k) || 0) + 1);
	}
	return [...m].map(([label, count]) => ({
		label,
		count
	})).sort((a, b) => b.count - a.count);
}
var RUNNING_TOO_LONG = 216e5;
/** Counts by status and last run, and the automations that need a look. */
function summarizeAutomations(list, now = Date.now()) {
	const status = (a) => automationStatusName(a.status);
	const attention = [];
	for (const a of list) {
		const s = status(a);
		if (isFailure(a.lastRunStatus)) attention.push({
			automation: a,
			reason: `Last run: ${a.lastRunStatus}`
		});
		else if (/error/i.test(s)) attention.push({
			automation: a,
			reason: `Status: ${s}`
		});
		else if (/^running$/i.test(s) && a.lastRunTime && now - time(a.lastRunTime) > RUNNING_TOO_LONG) attention.push({
			automation: a,
			reason: "Running for more than 6 hours"
		});
	}
	attention.sort((x, y) => time(y.automation.lastRunTime) - time(x.automation.lastRunTime));
	return {
		total: list.length,
		byStatus: countBy(list, status),
		byLastRun: countBy(list.filter((a) => a.lastRunStatus), (a) => String(a.lastRunStatus)),
		failedLastRun: list.filter((a) => isFailure(a.lastRunStatus)).length,
		attention
	};
}
var LIVE_JOURNEY = /^(published|running|scheduledtopublish)$/i;
function summarizeJourneys(list) {
	return {
		total: list.length,
		byStatus: countBy(list, (j) => statusWords(j.status)),
		live: list.filter((j) => LIVE_JOURNEY.test(j.status || "")).length
	};
}
// src/utils/journeyVersions.js
var LIVE_STATUSES = [
	"Published",
	"ScheduledToPublish",
	"Paused",
	"Finishing",
	"Sent"
];
new RegExp(`^(${LIVE_STATUSES.join("|")})$`, "i");
var liveRank = (status) => {
	const i = LIVE_STATUSES.indexOf(String(status || ""));
	return i < 0 ? LIVE_STATUSES.length : i;
};
/** The version to show for a journey: the published (or otherwise live) one, else the newest. */
function primaryVersion(versions) {
	return [...versions || []].sort((a, b) => liveRank(a.status) - liveRank(b.status) || (Number(b.version) || 0) - (Number(a.version) || 0))[0] || null;
}
/**
* List items of every version (`allVersions`) grouped per journey, in the order the
* journeys first appear: [{ id, key, name, versions (newest first), primary }].
*/
function groupJourneyVersions(items) {
	const groups = /* @__PURE__ */ new Map();
	for (const j of items || []) {
		if (!groups.has(j.id)) groups.set(j.id, {
			id: j.id,
			key: j.key,
			name: j.name,
			versions: []
		});
		groups.get(j.id).versions.push(j);
	}
	return [...groups.values()].map((g) => {
		g.versions.sort((a, b) => (Number(b.version) || 0) - (Number(a.version) || 0));
		const primary = primaryVersion(g.versions);
		return {
			...g,
			name: primary?.name || g.name,
			primary
		};
	});
}
// src/background/dashboard.js
var AS = (stack) => `https://mc.${stack}.marketingcloudapps.com/AutomationStudioFuel3/fuelapi`;
var JB = (stack) => `https://jbinteractions.${stack}.marketingcloudapps.com/fuelapi/interaction/v1`;
var PAGE = 50;
var MAX_ITEMS = 2e3;
var KEEP = 6e5;
var cache = /* @__PURE__ */ new Map();
var running = /* @__PURE__ */ new Map();
async function currentBU(stack) {
	try {
		const d = await sfmcFetch({ url: `https://mc.${stack}.exacttarget.com/cloud/fuelapi/platform-internal/v1/accounts/@current` });
		return {
			id: d?.accountId ?? d?.id ?? d?.memberId ?? "",
			name: d?.name || ""
		};
	} catch {
		return {
			id: "",
			name: ""
		};
	}
}
async function automationPage(stack, skip, top) {
	const d = await sfmcFetch({ url: `${AS(stack)}/legacy/v1/beta/automations/automation/definition/?$top=${top}&$skip=${skip}&$sort=${encodeURIComponent("lastRunTime desc")}&view=gridView` });
	return {
		entries: d?.entry || [],
		total: d?.totalResults ?? (d?.entry || []).length
	};
}
/** Every automation (up to 2,000), 50 at a time, as the overview reads them (feedback #28's fallback included). */
async function listAutomations(stack) {
	const first = await automationPage(stack, 0, PAGE);
	const items = [...first.entries];
	const seen = new Set(items.map((a) => a.id));
	let total = first.total;
	while (items.length < Math.min(total, MAX_ITEMS)) {
		let r = await automationPage(stack, items.length, PAGE);
		let fresh = r.entries.filter((a) => !seen.has(a.id));
		if (!fresh.length) {
			r = await automationPage(stack, 0, items.length + PAGE);
			fresh = r.entries.filter((a) => !seen.has(a.id));
		}
		if (!fresh.length) break;
		fresh.forEach((a) => {
			seen.add(a.id);
			items.push(a);
		});
		total = r.total;
	}
	return items;
}
/**
* Every journey once, by its live version when it has one (up to 2,000 versions): the
* latest version alone counted a published journey with a newer draft as a draft, so
* the card said 28 live where Home said 40 (live test, 2026-11-08).
*/
async function listJourneys(stack) {
	const items = [];
	for (let page = 1; items.length < MAX_ITEMS; page++) {
		const params = new URLSearchParams({
			$page: String(page),
			$pageSize: String(PAGE),
			$orderBy: "ModifiedDate DESC",
			mostRecentVersionOnly: "false"
		});
		const d = await sfmcFetch({ url: `${JB(stack)}/interactions?${params}` });
		const got = d?.items || [];
		items.push(...got);
		if (got.length < PAGE || items.length >= (d?.count ?? Infinity)) break;
	}
	return groupJourneyVersions(items).map((g) => g.primary);
}
/** What the card shows: plain data only (names, counts, ids for links). */
function dashboardSummary(automations, journeys, watches, stack, now = Date.now()) {
	const a = automations ? summarizeAutomations(automations, now) : null;
	const j = journeys ? summarizeJourneys(journeys) : null;
	const watched = Object.values(watches || {}).filter((w) => w.stack === stack).map((w) => ({
		type: watchType(w),
		id: w.id,
		name: w.name || w.id,
		status: watchType(w) === "journey" ? w.last?.status || "" : automationStatusName(w.last?.status),
		lastRunStatus: w.last?.lastRunStatus || ""
	}));
	return {
		at: now,
		automations: a && {
			total: a.total,
			failedLastRun: a.failedLastRun,
			byStatus: a.byStatus,
			attention: a.attention.slice(0, 5).map((x) => ({
				id: x.automation.id,
				name: x.automation.name,
				reason: x.reason
			})),
			attentionCount: a.attention.length
		},
		journeys: j && {
			total: j.total,
			live: j.live,
			byStatus: j.byStatus
		},
		watched
	};
}
async function build(stack, bu) {
	const [automations, journeys, store] = await Promise.all([
		listAutomations(stack).catch((e) => ({ error: e.message })),
		listJourneys(stack).catch((e) => ({ error: e.message })),
		storageGet("local", [WATCHES_KEY])
	]);
	const summary = dashboardSummary(Array.isArray(automations) ? automations : null, Array.isArray(journeys) ? journeys : null, store[WATCHES_KEY], stack);
	summary.businessUnit = bu.name;
	summary.errors = {
		automations: Array.isArray(automations) ? null : automations.error,
		journeys: Array.isArray(journeys) ? null : journeys.error
	};
	return summary;
}
/** The summary for `stack`: from the last 10 minutes unless `force`. */
async function getDashboardSummary(stack, { force = false } = {}) {
	if (!/^s\d+$/i.test(stack || "")) throw new Error("No SFMC stack.");
	const bu = await currentBU(stack);
	const key = `${stack}:${bu.id}`;
	const hit = cache.get(key);
	if (!force && hit && Date.now() - hit.at < KEEP) return hit.summary;
	if (!running.has(key)) running.set(key, build(stack, bu).then((summary) => {
		if (!summary.errors.automations || !summary.errors.journeys) cache.set(key, {
			at: Date.now(),
			summary
		});
		return summary;
	}).finally(() => running.delete(key)));
	return running.get(key);
}
// src/background/activityCapture.js
var queues = {};
var captureTiming = { beforeReadMs: 1e4 };
function withTimeout(promise, ms) {
	let timer;
	return Promise.race([promise, new Promise((resolve) => {
		timer = setTimeout(() => {
			console.warn("[Toolkit:SW] Reading the activity before its save took too long; keeping the saved version only.");
			resolve(null);
		}, ms);
	})]).finally(() => clearTimeout(timer));
}
var pendingSaves = {};
var completeTiming = { waitMs: 6e4 };
function waitForCompletion(requestId) {
	return new Promise((resolve) => {
		const timer = setTimeout(() => {
			delete pendingSaves[requestId];
			resolve(false);
		}, completeTiming.waitMs);
		pendingSaves[requestId] = (ok) => {
			clearTimeout(timer);
			delete pendingSaves[requestId];
			resolve(ok);
		};
	});
}
function activitySaveCompleted(details) {
	const done = pendingSaves[details?.requestId];
	if (done) done(!details.error && details.statusCode >= 200 && details.statusCode < 300);
}
function captureActivity(details) {
	const hit = matchActivitySave(details?.url, details?.method);
	if (!hit || policyNow().disableHistory) return;
	const body = decodeRequestBody(details.requestBody);
	let saved = pickActivity(hit.kind, body);
	if (!saved && body) return;
	const url = activityUrl(hit.kind, hit.stack, hit.id);
	const savedLater = saved ? null : waitForCompletion(details.requestId).then((ok) => {
		if (!ok) return null;
		return sfmcFetch({ url }).then((o) => pickActivity(hit.kind, o)).catch((e) => {
			console.warn("[Toolkit:SW] Could not read the activity after its save:", e?.message);
			return null;
		});
	});
	const before = withTimeout(sfmcFetch({ url }).catch((e) => {
		console.warn("[Toolkit:SW] Could not read the activity before its save:", e?.message);
		return null;
	}), captureTiming.beforeReadMs);
	const key = recordKey(hit.kind, hit.id);
	const savedAt = details.timeStamp || Date.now();
	const run = (queues[key] || Promise.resolve()).then(async () => {
		if (!saved) saved = await savedLater;
		if (saved) await store(hit, key, saved, before, savedAt);
	});
	queues[key] = run.catch(() => {});
	return run;
}
async function store(hit, key, saved, beforePromise, savedAt) {
	const prefs = await storageGet("local", [
		ACTIVITY_SAVER_SETTING,
		ACTIVITY_MAX_SETTING,
		key
	]);
	if (prefs["_activitySaverEnabled"] === false) return;
	const beforeObj = pickActivity(hit.kind, await beforePromise);
	const incoming = [];
	if (beforeObj) incoming.push(makeVersion(beforeObj, {
		savedAt: savedAt - 1,
		source: "before-save",
		stack: hit.stack
	}));
	incoming.push(makeVersion(saved, {
		savedAt,
		source: "saved",
		stack: hit.stack
	}));
	const prev = prefs[key];
	const { versions, added } = addVersions(prev?.versions, incoming, prefs["_activityMaxVersions"] ?? 50);
	if (!added) return;
	const latest = versions[0];
	await storageSet("local", { [key]: {
		id: key,
		kind: hit.kind,
		activityId: hit.id,
		name: latest.name || prev?.name || "",
		key: latest.key || prev?.key || "",
		stack: hit.stack,
		businessUnit: prev?.businessUnit || null,
		timeStamp: prev?.timeStamp || savedAt,
		versions
	} });
	console.info(`[Toolkit:SW] Saved ${added} version(s) of ${hit.kind} "${latest.name || hit.id}" (${key})`);
	if (!prev?.businessUnit) tagActivityBusinessUnit(key, hit.stack);
}
async function tagActivityBusinessUnit(key, stack) {
	try {
		const bu = await fetchCurrentBusinessUnit(stack);
		if (!bu) return;
		const rec = (await storageGet("local", key))[key];
		if (!rec || rec.businessUnit?.name) return;
		await storageSet("local", { [key]: {
			...rec,
			businessUnit: bu
		} });
	} catch (e) {
		console.warn("[Toolkit:SW] Could not tag the business unit:", e?.message);
	}
}
// src/background/index.js
onForgetStack(dropMcaToken);
setOnMintFailure(forgetStack);
restoreCsrfTokens();
restorePageHeaders();
restoreJbCsrf();
loadEmailSaverPrefs();
watchForUpdates();
watchPolicy();
chrome.runtime.onInstalled?.addListener(() => {
	slimStoredAssets().catch(() => 0).then(() => makeRoom(0));
});
updateBadge();
var APP_PAGE = "app.html";
chrome.action?.onClicked?.addListener((tab) => {
	createTab(nextTo(tab, { url: chrome.runtime.getURL(APP_PAGE) }));
});
chrome.tabs?.onActivated?.addListener(({ tabId }) => {
	chrome.tabs.get(tabId, (tab) => {
		if (!chrome.runtime.lastError && tab) rememberActiveStack(tab.url, tab.id);
	});
});
chrome.tabs?.onUpdated?.addListener((tabId, info, tab) => {
	if (info.status === "complete" && tab?.active) rememberActiveStack(tab.url, tab.id);
});
chrome.storage?.onChanged?.addListener((changes, area) => {
	if (area !== "local") return;
	const prefs = {};
	for (const k of [
		"_emailSaverEnabled",
		"_emailSaveDebounce",
		"_cloudPageSaverEnabled"
	]) if (k in changes) prefs[k] = changes[k].newValue;
	applyEmailSaverPrefs(prefs);
});
chrome.webRequest?.onBeforeRequest.addListener(noteRequestStack, { urls: ["https://*.exacttarget.com/*", "https://*.marketingcloudapps.com/*"] });
chrome.webRequest?.onBeforeSendHeaders.addListener(sniffCsrf, { urls: ["https://*.exacttarget.com/*"] }, ["requestHeaders", "extraHeaders"]);
chrome.webRequest?.onBeforeSendHeaders.addListener(sniffPageHeaders, { urls: ["https://*.marketingcloudapps.com/contactsmeta/*"] }, ["requestHeaders", "extraHeaders"]);
chrome.webRequest?.onBeforeSendHeaders.addListener(sniffJbCsrf, { urls: ["https://*.marketingcloudapps.com/fuelapi/*"] }, ["requestHeaders", "extraHeaders"]);
chrome.webRequest?.onBeforeRequest.addListener(captureQueryStudio, { urls: QUERY_STUDIO_CREATE_URLS }, ["requestBody"]);
chrome.webRequest?.onBeforeRequest.addListener(captureEmail, { urls: ["https://*.marketingcloudapps.com/fuelapi/asset/v1/content/assets/*"] }, ["requestBody"]);
var ACTIVITY_URLS = ["https://*.marketingcloudapps.com/AutomationStudioFuel3/*", "https://*.exacttarget.com/*AutomationStudioFuel3/*"];
chrome.webRequest?.onBeforeRequest.addListener(captureActivity, { urls: ACTIVITY_URLS }, ["requestBody"]);
chrome.webRequest?.onCompleted?.addListener(activitySaveCompleted, { urls: ACTIVITY_URLS });
chrome.webRequest?.onErrorOccurred?.addListener(activitySaveCompleted, { urls: ACTIVITY_URLS });
var isSfmcUrl = (u) => /^https:\/\/[^/]*\.(exacttarget|marketingcloudapps|marketingcloud|salesforce-marketingcloud)\.com\//.test(u || "");
var isLoggedInUrl = (u) => !u.includes("/login") && !u.includes("mc.login.") && !u.includes("sso");
async function connectionStatus() {
	const { stack } = await resolveAndPublish();
	if (stack && !isMcaTokenReady(stack) && !mintBackoff(stack)) getMcaToken(stack);
	let coreOpen = false;
	let contentBuilderOpen = false;
	for (const t of await queryTabs({})) {
		const u = t.url || "";
		if (!isSfmcUrl(u) || !isLoggedInUrl(u)) continue;
		if (u.includes("content-builder.")) contentBuilderOpen = true;
		else if (u.includes("mc.") || u.includes("members.")) coreOpen = true;
	}
	return {
		stack,
		connected: !!stack,
		tokenReady: !!getCoreCsrf(stack),
		mcaTokenReady: isMcaTokenReady(stack),
		areas: {
			core: { open: coreOpen },
			contentBuilder: { open: contentBuilderOpen }
		}
	};
}
function errorReply(err) {
	return {
		error: err?.message || String(err),
		code: err?.code || null,
		status: err?.status ?? null,
		app: err?.app || null
	};
}
var handlers = {
	PING: () => ({ ok: true }),
	GET_SESSION: (m) => getSession(m.stackKey),
	GET_STACKS: () => getStacks(),
	SET_STACK_OVERRIDE: (m) => setStackOverride(m.stack),
	GET_CONNECTION_STATUS: () => connectionStatus(),
	SFMC_SESSION_STATUS: async (m) => ({ status: await sessionStatus(m.stack || (await resolveAndPublish()).stack) }),
	SFMC_CONNECT_APP: async (m) => {
		await connectApp(m.stack, m.appId, { onLoggedOut: forgetStack });
		return { ok: true };
	},
	SFMC_WARM_UP: async (m) => {
		const { _autoStartSessions } = await storageGet("local", ["_autoStartSessions"]);
		if (_autoStartSessions === false && !m.force) return { result: { skipped: "turned off" } };
		return { result: await warmUpMissing(m.stack || (await resolveAndPublish()).stack, {
			force: !!m.force,
			onLoggedOut: forgetStack
		}) };
	},
	SFMC_FETCH: async (m) => ({ data: await sfmcFetch(m) }),
	SAVE_RECORDS: async (m) => {
		await saveRecords(m.records || {});
		return { status: "OK" };
	},
	IMPORT_SHARED_QUERY: async (m, sender) => {
		const records = sharedQueryRecords(m.records, sender?.url);
		if (!records) return { error: "Not a share page or not a query." };
		if ((await getPolicy()).disableShare) return { error: "Sharing is turned off by policy." };
		await saveRecords(records);
		return { status: "OK" };
	},
	RENAME_QUERY: async (m) => {
		await renameQuery(m.id, m.name);
		return { status: "OK" };
	},
	SFMC_CONTEXT_CAPTURED: (m) => {
		captureContext(m.context);
		if (m.context?.stackKey) checkWatches(m.context.stackKey).catch(() => void 0);
		return null;
	},
	WATCH_CHECK: async (m) => ({ result: await checkWatches(m.stack || (await resolveAndPublish()).stack, { force: !!m.force }) }),
	WATCH_BADGE: async () => {
		await updateBadge();
		return { ok: true };
	},
	AUTOMATION_SUMMARY: async (m) => ({ summary: await automationSummary(m.stack, m.id) }),
	OPEN_APP: (m, sender) => {
		const path = typeof m.path === "string" && m.path.startsWith("/") ? m.path : "/";
		createTab(nextTo(sender?.tab, { url: chrome.runtime.getURL(`${APP_PAGE}#${path}`) }));
		return { ok: true };
	},
	DASHBOARD_SUMMARY: async (m) => ({ summary: await getDashboardSummary(m.stack, { force: !!m.force }) }),
	OPEN_SFMC_LINK: async (m, sender) => {
		let ok = false;
		try {
			const u = new URL(m.url);
			ok = u.protocol === "https:" && /^mc\.s\d+\.exacttarget\.com$/i.test(u.hostname);
		} catch {}
		if (!ok) return { error: "Not an SFMC link." };
		return openSfmcLink(m.url, sender?.tab);
	},
	MCA_TOKEN_CAPTURED: (m, sender) => {
		handleCapturedToken(sender, m.accessToken);
		return null;
	}
};
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	const handler = handlers[message?.type];
	if (!handler) return false;
	if (!messageAllowed(message, sender, chrome.runtime.getURL(""))) {
		sendResponse({ error: "Not allowed from this page." });
		return false;
	}
	Promise.resolve().then(() => handler(message, sender)).then((reply) => sendResponse(reply ?? {}), (err) => sendResponse(errorReply(err)));
	return true;
});
export { connectionStatus };
